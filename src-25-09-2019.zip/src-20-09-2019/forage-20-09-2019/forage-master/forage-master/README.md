# Brief
</br>
</br></br>

The contribution of this project is at least twofold: the end-user is provided with either a
computer machine or an ideal tutor. On the other hand an administrative user is provided with
close contact reports that can be used in planning and forecasting aside from the conventional application data maintenance tasks.</br></br>
![Data Model B](https://user-images.githubusercontent.com/26520289/61610723-3784e080-ac5a-11e9-9b4d-eb47d506df1a.PNG)</br>
![Data Model A](https://user-images.githubusercontent.com/26520289/61610724-381d7700-ac5a-11e9-937a-2652b6890cdf.PNG) </br>
![Form Login](https://user-images.githubusercontent.com/26520289/61609779-80876580-ac57-11e9-81a4-dbc63682d1e1.png)</br>
![Form Student Registration](https://user-images.githubusercontent.com/26520289/61610405-5e8ee280-ac59-11e9-9e7c-6080a02dbeb3.PNG)</br>
![Form Tutor Registration](https://user-images.githubusercontent.com/26520289/61610411-63ec2d00-ac59-11e9-92b4-915decf3fc7f.PNG)</br>
![Form Students Tutors Main Dashboard](https://user-images.githubusercontent.com/26520289/61609802-91d07200-ac57-11e9-8144-f1bdebb075d4.PNG)</br>
![Form View Labs](https://user-images.githubusercontent.com/26520289/61609818-9b59da00-ac57-11e9-948a-a1da9046c662.PNG)</br>
![Form Find Machine](https://user-images.githubusercontent.com/26520289/61609866-b7f61200-ac57-11e9-8d14-487d341311a8.PNG)
