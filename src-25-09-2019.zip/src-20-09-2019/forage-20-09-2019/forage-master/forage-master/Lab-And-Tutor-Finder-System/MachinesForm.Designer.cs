﻿namespace Lab_And_Tutor_Finder_System
{
    partial class MachinesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MachinesForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button154 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.button182 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button200 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button232 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button236 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button239 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.button243 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button248 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button260 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button262 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button276 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button280 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button284 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button287 = new System.Windows.Forms.Button();
            this.button288 = new System.Windows.Forms.Button();
            this.button289 = new System.Windows.Forms.Button();
            this.button290 = new System.Windows.Forms.Button();
            this.button291 = new System.Windows.Forms.Button();
            this.button292 = new System.Windows.Forms.Button();
            this.button293 = new System.Windows.Forms.Button();
            this.button294 = new System.Windows.Forms.Button();
            this.button295 = new System.Windows.Forms.Button();
            this.button296 = new System.Windows.Forms.Button();
            this.button297 = new System.Windows.Forms.Button();
            this.button298 = new System.Windows.Forms.Button();
            this.button299 = new System.Windows.Forms.Button();
            this.button300 = new System.Windows.Forms.Button();
            this.button301 = new System.Windows.Forms.Button();
            this.button302 = new System.Windows.Forms.Button();
            this.button303 = new System.Windows.Forms.Button();
            this.button304 = new System.Windows.Forms.Button();
            this.button305 = new System.Windows.Forms.Button();
            this.button306 = new System.Windows.Forms.Button();
            this.button307 = new System.Windows.Forms.Button();
            this.button308 = new System.Windows.Forms.Button();
            this.button309 = new System.Windows.Forms.Button();
            this.button310 = new System.Windows.Forms.Button();
            this.button311 = new System.Windows.Forms.Button();
            this.button312 = new System.Windows.Forms.Button();
            this.button313 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(10, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1356, 590);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button154
            // 
            this.button154.BackColor = System.Drawing.Color.Lime;
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Location = new System.Drawing.Point(563, 617);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(14, 20);
            this.button154.TabIndex = 175;
            this.button154.UseVisualStyleBackColor = false;
            // 
            // button156
            // 
            this.button156.BackColor = System.Drawing.Color.Yellow;
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Location = new System.Drawing.Point(616, 617);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(14, 20);
            this.button156.TabIndex = 178;
            this.button156.UseVisualStyleBackColor = false;
            // 
            // button158
            // 
            this.button158.BackColor = System.Drawing.Color.Lime;
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Location = new System.Drawing.Point(603, 617);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(14, 20);
            this.button158.TabIndex = 176;
            this.button158.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(82, 140);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(10, 10);
            this.button1.TabIndex = 179;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Yellow;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(99, 140);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(10, 10);
            this.button2.TabIndex = 180;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Yellow;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(133, 140);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(10, 10);
            this.button3.TabIndex = 182;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Yellow;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(116, 140);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(10, 10);
            this.button4.TabIndex = 181;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Yellow;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(200, 140);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(10, 10);
            this.button5.TabIndex = 186;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Yellow;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(183, 140);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(10, 10);
            this.button6.TabIndex = 185;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Yellow;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(166, 140);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(10, 10);
            this.button7.TabIndex = 184;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Yellow;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(149, 140);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(10, 10);
            this.button8.TabIndex = 183;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Yellow;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(100, 194);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(10, 10);
            this.button9.TabIndex = 193;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Yellow;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(82, 193);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(10, 10);
            this.button10.TabIndex = 192;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Yellow;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(284, 140);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(10, 10);
            this.button11.TabIndex = 191;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Yellow;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(267, 140);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(10, 10);
            this.button12.TabIndex = 190;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Yellow;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(251, 140);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(10, 10);
            this.button13.TabIndex = 189;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Yellow;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(234, 140);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(10, 10);
            this.button14.TabIndex = 188;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Yellow;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(217, 140);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(10, 10);
            this.button15.TabIndex = 187;
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Yellow;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(217, 193);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(10, 10);
            this.button16.TabIndex = 200;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Yellow;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(200, 193);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(10, 10);
            this.button17.TabIndex = 199;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Yellow;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(183, 194);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(10, 10);
            this.button18.TabIndex = 198;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Yellow;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(166, 193);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(10, 10);
            this.button19.TabIndex = 197;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Yellow;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(150, 194);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(10, 10);
            this.button20.TabIndex = 196;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Yellow;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(133, 194);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(10, 10);
            this.button21.TabIndex = 195;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Yellow;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(116, 193);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(10, 10);
            this.button22.TabIndex = 194;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Yellow;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(284, 265);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(10, 10);
            this.button23.TabIndex = 213;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Yellow;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(267, 265);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(10, 10);
            this.button24.TabIndex = 212;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Yellow;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(251, 265);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(10, 10);
            this.button25.TabIndex = 211;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Yellow;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(234, 265);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(10, 10);
            this.button26.TabIndex = 210;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Yellow;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(217, 265);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(10, 10);
            this.button27.TabIndex = 209;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Yellow;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(200, 265);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(10, 10);
            this.button28.TabIndex = 208;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Yellow;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(183, 265);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(10, 10);
            this.button29.TabIndex = 207;
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Yellow;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(166, 265);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(10, 10);
            this.button30.TabIndex = 206;
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Yellow;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(149, 265);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(10, 10);
            this.button31.TabIndex = 205;
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Yellow;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(133, 265);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(10, 10);
            this.button32.TabIndex = 204;
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Yellow;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(116, 265);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(10, 10);
            this.button33.TabIndex = 203;
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Yellow;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(99, 265);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(10, 10);
            this.button34.TabIndex = 202;
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Yellow;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(82, 265);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(10, 10);
            this.button35.TabIndex = 201;
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Yellow;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(234, 194);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(10, 10);
            this.button36.TabIndex = 214;
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Yellow;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(251, 194);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(10, 10);
            this.button37.TabIndex = 215;
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.Yellow;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(251, 206);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(10, 10);
            this.button38.TabIndex = 226;
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Yellow;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(234, 207);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(10, 10);
            this.button39.TabIndex = 225;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Yellow;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(217, 207);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(10, 10);
            this.button40.TabIndex = 224;
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Yellow;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(200, 207);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(10, 10);
            this.button41.TabIndex = 223;
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Yellow;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(183, 207);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(10, 10);
            this.button42.TabIndex = 222;
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.Yellow;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(166, 207);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(10, 10);
            this.button43.TabIndex = 221;
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Yellow;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(150, 207);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(10, 10);
            this.button44.TabIndex = 220;
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Yellow;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(133, 207);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(10, 10);
            this.button45.TabIndex = 219;
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Yellow;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(116, 207);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(10, 10);
            this.button46.TabIndex = 218;
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Yellow;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(99, 207);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(10, 10);
            this.button47.TabIndex = 217;
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Yellow;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(82, 207);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(10, 10);
            this.button48.TabIndex = 216;
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Yellow;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(383, 131);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(10, 10);
            this.button49.TabIndex = 227;
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.Yellow;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(383, 149);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(10, 10);
            this.button50.TabIndex = 228;
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Yellow;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(383, 184);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(10, 10);
            this.button51.TabIndex = 230;
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Yellow;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(383, 167);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(10, 10);
            this.button52.TabIndex = 229;
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.Yellow;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(383, 220);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(10, 10);
            this.button53.TabIndex = 232;
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.Yellow;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(383, 203);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(10, 10);
            this.button54.TabIndex = 231;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Yellow;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(411, 220);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(10, 10);
            this.button55.TabIndex = 238;
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Yellow;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(411, 202);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(10, 10);
            this.button56.TabIndex = 237;
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.Yellow;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(411, 184);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(10, 10);
            this.button57.TabIndex = 236;
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Yellow;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(411, 167);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(10, 10);
            this.button58.TabIndex = 235;
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Yellow;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(411, 149);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(10, 10);
            this.button59.TabIndex = 234;
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Yellow;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(411, 131);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(10, 10);
            this.button60.TabIndex = 233;
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Yellow;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(424, 220);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(10, 10);
            this.button61.TabIndex = 244;
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.Yellow;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(425, 202);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(10, 10);
            this.button62.TabIndex = 243;
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Yellow;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(424, 184);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(10, 10);
            this.button63.TabIndex = 242;
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.Yellow;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(425, 167);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(10, 10);
            this.button64.TabIndex = 241;
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Yellow;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(425, 149);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(10, 10);
            this.button65.TabIndex = 240;
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.Yellow;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(425, 131);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(10, 10);
            this.button66.TabIndex = 239;
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Yellow;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(452, 220);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(10, 10);
            this.button67.TabIndex = 250;
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Yellow;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(452, 202);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(10, 10);
            this.button68.TabIndex = 249;
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.Yellow;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(452, 185);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(10, 10);
            this.button69.TabIndex = 248;
            this.button69.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.Yellow;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(451, 167);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(10, 10);
            this.button70.TabIndex = 247;
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Yellow;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(452, 149);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(10, 10);
            this.button71.TabIndex = 246;
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Yellow;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(452, 131);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(10, 10);
            this.button72.TabIndex = 245;
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.Yellow;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(466, 220);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(10, 10);
            this.button73.TabIndex = 256;
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.Yellow;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(465, 202);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(10, 10);
            this.button74.TabIndex = 255;
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.Yellow;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(466, 185);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(10, 10);
            this.button75.TabIndex = 254;
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Yellow;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(466, 167);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(10, 10);
            this.button76.TabIndex = 253;
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Yellow;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(466, 149);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(10, 10);
            this.button77.TabIndex = 252;
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Yellow;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(465, 131);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(10, 10);
            this.button78.TabIndex = 251;
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Yellow;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(507, 149);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(10, 10);
            this.button79.TabIndex = 260;
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Yellow;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(506, 131);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(10, 10);
            this.button80.TabIndex = 259;
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.Yellow;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(493, 149);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(10, 10);
            this.button81.TabIndex = 258;
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.Yellow;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(493, 131);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(10, 10);
            this.button82.TabIndex = 257;
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.Yellow;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(507, 185);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(10, 10);
            this.button83.TabIndex = 264;
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Yellow;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(506, 167);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(10, 10);
            this.button84.TabIndex = 263;
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.Yellow;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(493, 185);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(10, 10);
            this.button85.TabIndex = 262;
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.Yellow;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(493, 167);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(10, 10);
            this.button86.TabIndex = 261;
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.Yellow;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(548, 149);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(10, 10);
            this.button87.TabIndex = 272;
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Yellow;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(547, 131);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(10, 10);
            this.button88.TabIndex = 271;
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.Yellow;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(534, 149);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(10, 10);
            this.button89.TabIndex = 270;
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.Yellow;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(534, 131);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(10, 10);
            this.button90.TabIndex = 269;
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.Yellow;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(507, 221);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(10, 10);
            this.button91.TabIndex = 268;
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.Yellow;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(506, 202);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(10, 10);
            this.button92.TabIndex = 267;
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.Yellow;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(493, 220);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(10, 10);
            this.button93.TabIndex = 266;
            this.button93.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.Yellow;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(493, 202);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(10, 10);
            this.button94.TabIndex = 265;
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.Yellow;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(548, 220);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(10, 10);
            this.button95.TabIndex = 280;
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.Color.Yellow;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Location = new System.Drawing.Point(547, 202);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(10, 10);
            this.button96.TabIndex = 279;
            this.button96.UseVisualStyleBackColor = false;
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.Yellow;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(534, 220);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(10, 10);
            this.button97.TabIndex = 278;
            this.button97.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.Yellow;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(534, 202);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(10, 10);
            this.button98.TabIndex = 277;
            this.button98.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.Color.Yellow;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Location = new System.Drawing.Point(548, 184);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(10, 10);
            this.button99.TabIndex = 276;
            this.button99.UseVisualStyleBackColor = false;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.Yellow;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(547, 166);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(10, 10);
            this.button100.TabIndex = 275;
            this.button100.UseVisualStyleBackColor = false;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.Yellow;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(534, 184);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(10, 10);
            this.button101.TabIndex = 274;
            this.button101.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.Color.Yellow;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Location = new System.Drawing.Point(534, 166);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(10, 10);
            this.button102.TabIndex = 273;
            this.button102.UseVisualStyleBackColor = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.Yellow;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Location = new System.Drawing.Point(576, 220);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(10, 10);
            this.button103.TabIndex = 286;
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.Yellow;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Location = new System.Drawing.Point(575, 202);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(10, 10);
            this.button104.TabIndex = 285;
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.Color.Yellow;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Location = new System.Drawing.Point(576, 184);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(10, 10);
            this.button105.TabIndex = 284;
            this.button105.UseVisualStyleBackColor = false;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.Yellow;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(575, 166);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(10, 10);
            this.button106.TabIndex = 283;
            this.button106.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.Yellow;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Location = new System.Drawing.Point(576, 149);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(10, 10);
            this.button107.TabIndex = 282;
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.Yellow;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Location = new System.Drawing.Point(575, 131);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(10, 10);
            this.button108.TabIndex = 281;
            this.button108.UseVisualStyleBackColor = false;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.Yellow;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(679, 220);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(10, 10);
            this.button109.TabIndex = 292;
            this.button109.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.Yellow;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Location = new System.Drawing.Point(679, 202);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(10, 10);
            this.button110.TabIndex = 291;
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.Yellow;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Location = new System.Drawing.Point(679, 184);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(10, 10);
            this.button111.TabIndex = 290;
            this.button111.UseVisualStyleBackColor = false;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.Yellow;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Location = new System.Drawing.Point(679, 167);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(10, 10);
            this.button112.TabIndex = 289;
            this.button112.UseVisualStyleBackColor = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.Yellow;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(679, 149);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(10, 10);
            this.button113.TabIndex = 288;
            this.button113.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.Color.Yellow;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Location = new System.Drawing.Point(679, 131);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(10, 10);
            this.button114.TabIndex = 287;
            this.button114.UseVisualStyleBackColor = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.Yellow;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Location = new System.Drawing.Point(737, 167);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(10, 10);
            this.button115.TabIndex = 298;
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.Color.Yellow;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Location = new System.Drawing.Point(723, 220);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(10, 10);
            this.button117.TabIndex = 296;
            this.button117.UseVisualStyleBackColor = false;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.Color.Yellow;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(723, 202);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(10, 10);
            this.button118.TabIndex = 295;
            this.button118.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.Color.Yellow;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Location = new System.Drawing.Point(723, 184);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(10, 10);
            this.button119.TabIndex = 294;
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.Color.Yellow;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Location = new System.Drawing.Point(723, 167);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(10, 10);
            this.button120.TabIndex = 293;
            this.button120.UseVisualStyleBackColor = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.Yellow;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Location = new System.Drawing.Point(736, 220);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(10, 10);
            this.button116.TabIndex = 301;
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.Color.Yellow;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(737, 202);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(10, 10);
            this.button121.TabIndex = 300;
            this.button121.UseVisualStyleBackColor = false;
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.Color.Yellow;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(736, 185);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(10, 10);
            this.button122.TabIndex = 299;
            this.button122.UseVisualStyleBackColor = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.Color.Yellow;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Location = new System.Drawing.Point(411, 292);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(10, 10);
            this.button123.TabIndex = 304;
            this.button123.UseVisualStyleBackColor = false;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.Yellow;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Location = new System.Drawing.Point(411, 274);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(10, 10);
            this.button124.TabIndex = 303;
            this.button124.UseVisualStyleBackColor = false;
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.Color.Yellow;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(411, 257);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(10, 10);
            this.button125.TabIndex = 302;
            this.button125.UseVisualStyleBackColor = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.Color.Yellow;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Location = new System.Drawing.Point(425, 292);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(10, 10);
            this.button126.TabIndex = 307;
            this.button126.UseVisualStyleBackColor = false;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.Yellow;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Location = new System.Drawing.Point(425, 274);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(10, 10);
            this.button127.TabIndex = 306;
            this.button127.UseVisualStyleBackColor = false;
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.Color.Yellow;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Location = new System.Drawing.Point(425, 257);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(10, 10);
            this.button128.TabIndex = 305;
            this.button128.UseVisualStyleBackColor = false;
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.Color.Yellow;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(466, 291);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(10, 10);
            this.button129.TabIndex = 313;
            this.button129.UseVisualStyleBackColor = false;
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.Color.Yellow;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(465, 273);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(10, 10);
            this.button130.TabIndex = 312;
            this.button130.UseVisualStyleBackColor = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.Color.Yellow;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Location = new System.Drawing.Point(466, 256);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(10, 10);
            this.button131.TabIndex = 311;
            this.button131.UseVisualStyleBackColor = false;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.Color.Yellow;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Location = new System.Drawing.Point(452, 291);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(10, 10);
            this.button132.TabIndex = 310;
            this.button132.UseVisualStyleBackColor = false;
            // 
            // button133
            // 
            this.button133.BackColor = System.Drawing.Color.Yellow;
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(452, 273);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(10, 10);
            this.button133.TabIndex = 309;
            this.button133.UseVisualStyleBackColor = false;
            // 
            // button134
            // 
            this.button134.BackColor = System.Drawing.Color.Yellow;
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(452, 256);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(10, 10);
            this.button134.TabIndex = 308;
            this.button134.UseVisualStyleBackColor = false;
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.Color.Yellow;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Location = new System.Drawing.Point(506, 291);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(10, 10);
            this.button135.TabIndex = 319;
            this.button135.UseVisualStyleBackColor = false;
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.Yellow;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Location = new System.Drawing.Point(506, 273);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(10, 10);
            this.button136.TabIndex = 318;
            this.button136.UseVisualStyleBackColor = false;
            // 
            // button137
            // 
            this.button137.BackColor = System.Drawing.Color.Yellow;
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(506, 256);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(10, 10);
            this.button137.TabIndex = 317;
            this.button137.UseVisualStyleBackColor = false;
            // 
            // button138
            // 
            this.button138.BackColor = System.Drawing.Color.Yellow;
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Location = new System.Drawing.Point(492, 291);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(10, 10);
            this.button138.TabIndex = 316;
            this.button138.UseVisualStyleBackColor = false;
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.Color.Yellow;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Location = new System.Drawing.Point(492, 273);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(10, 10);
            this.button139.TabIndex = 315;
            this.button139.UseVisualStyleBackColor = false;
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.Yellow;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Location = new System.Drawing.Point(492, 256);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(10, 10);
            this.button140.TabIndex = 314;
            this.button140.UseVisualStyleBackColor = false;
            // 
            // button141
            // 
            this.button141.BackColor = System.Drawing.Color.Yellow;
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Location = new System.Drawing.Point(547, 291);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(10, 10);
            this.button141.TabIndex = 325;
            this.button141.UseVisualStyleBackColor = false;
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.Color.Yellow;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Location = new System.Drawing.Point(547, 273);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(10, 10);
            this.button142.TabIndex = 324;
            this.button142.UseVisualStyleBackColor = false;
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.Yellow;
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Location = new System.Drawing.Point(547, 255);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(10, 10);
            this.button143.TabIndex = 323;
            this.button143.UseVisualStyleBackColor = false;
            // 
            // button144
            // 
            this.button144.BackColor = System.Drawing.Color.Yellow;
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Location = new System.Drawing.Point(533, 291);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(10, 10);
            this.button144.TabIndex = 322;
            this.button144.UseVisualStyleBackColor = false;
            // 
            // button145
            // 
            this.button145.BackColor = System.Drawing.Color.Yellow;
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(534, 273);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(10, 10);
            this.button145.TabIndex = 321;
            this.button145.UseVisualStyleBackColor = false;
            // 
            // button146
            // 
            this.button146.BackColor = System.Drawing.Color.Yellow;
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(534, 256);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(10, 10);
            this.button146.TabIndex = 320;
            this.button146.UseVisualStyleBackColor = false;
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.Color.Yellow;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Location = new System.Drawing.Point(381, 292);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(10, 10);
            this.button147.TabIndex = 326;
            this.button147.UseVisualStyleBackColor = false;
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.Yellow;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Location = new System.Drawing.Point(576, 293);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(10, 10);
            this.button148.TabIndex = 329;
            this.button148.UseVisualStyleBackColor = false;
            // 
            // button149
            // 
            this.button149.BackColor = System.Drawing.Color.Yellow;
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(576, 275);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(10, 10);
            this.button149.TabIndex = 328;
            this.button149.UseVisualStyleBackColor = false;
            // 
            // button150
            // 
            this.button150.BackColor = System.Drawing.Color.Yellow;
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Location = new System.Drawing.Point(576, 257);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(10, 10);
            this.button150.TabIndex = 327;
            this.button150.UseVisualStyleBackColor = false;
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.Yellow;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Location = new System.Drawing.Point(723, 292);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(10, 10);
            this.button151.TabIndex = 332;
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.Yellow;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Location = new System.Drawing.Point(723, 274);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(10, 10);
            this.button152.TabIndex = 331;
            this.button152.UseVisualStyleBackColor = false;
            // 
            // button153
            // 
            this.button153.BackColor = System.Drawing.Color.Yellow;
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Location = new System.Drawing.Point(723, 256);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(10, 10);
            this.button153.TabIndex = 330;
            this.button153.UseVisualStyleBackColor = false;
            // 
            // button155
            // 
            this.button155.BackColor = System.Drawing.Color.Yellow;
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Location = new System.Drawing.Point(779, 220);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(10, 10);
            this.button155.TabIndex = 344;
            this.button155.UseVisualStyleBackColor = false;
            // 
            // button157
            // 
            this.button157.BackColor = System.Drawing.Color.Yellow;
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Location = new System.Drawing.Point(778, 202);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(10, 10);
            this.button157.TabIndex = 343;
            this.button157.UseVisualStyleBackColor = false;
            // 
            // button159
            // 
            this.button159.BackColor = System.Drawing.Color.Yellow;
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Location = new System.Drawing.Point(765, 220);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(10, 10);
            this.button159.TabIndex = 342;
            this.button159.UseVisualStyleBackColor = false;
            // 
            // button160
            // 
            this.button160.BackColor = System.Drawing.Color.Yellow;
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button160.Location = new System.Drawing.Point(765, 202);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(10, 10);
            this.button160.TabIndex = 341;
            this.button160.UseVisualStyleBackColor = false;
            // 
            // button161
            // 
            this.button161.BackColor = System.Drawing.Color.Yellow;
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Location = new System.Drawing.Point(779, 184);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(10, 10);
            this.button161.TabIndex = 340;
            this.button161.UseVisualStyleBackColor = false;
            // 
            // button162
            // 
            this.button162.BackColor = System.Drawing.Color.Yellow;
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Location = new System.Drawing.Point(778, 165);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(10, 10);
            this.button162.TabIndex = 339;
            this.button162.UseVisualStyleBackColor = false;
            // 
            // button163
            // 
            this.button163.BackColor = System.Drawing.Color.Yellow;
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Location = new System.Drawing.Point(765, 184);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(10, 10);
            this.button163.TabIndex = 338;
            this.button163.UseVisualStyleBackColor = false;
            // 
            // button164
            // 
            this.button164.BackColor = System.Drawing.Color.Yellow;
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Location = new System.Drawing.Point(765, 166);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(10, 10);
            this.button164.TabIndex = 337;
            this.button164.UseVisualStyleBackColor = false;
            // 
            // button165
            // 
            this.button165.BackColor = System.Drawing.Color.Yellow;
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Location = new System.Drawing.Point(778, 149);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(10, 10);
            this.button165.TabIndex = 336;
            this.button165.UseVisualStyleBackColor = false;
            // 
            // button166
            // 
            this.button166.BackColor = System.Drawing.Color.Yellow;
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Location = new System.Drawing.Point(778, 131);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(10, 10);
            this.button166.TabIndex = 335;
            this.button166.UseVisualStyleBackColor = false;
            // 
            // button167
            // 
            this.button167.BackColor = System.Drawing.Color.Yellow;
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Location = new System.Drawing.Point(764, 149);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(10, 10);
            this.button167.TabIndex = 334;
            this.button167.UseVisualStyleBackColor = false;
            // 
            // button168
            // 
            this.button168.BackColor = System.Drawing.Color.Yellow;
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Location = new System.Drawing.Point(765, 131);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(10, 10);
            this.button168.TabIndex = 333;
            this.button168.UseVisualStyleBackColor = false;
            // 
            // button169
            // 
            this.button169.BackColor = System.Drawing.Color.Yellow;
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Location = new System.Drawing.Point(888, 219);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(10, 10);
            this.button169.TabIndex = 356;
            this.button169.UseVisualStyleBackColor = false;
            // 
            // button170
            // 
            this.button170.BackColor = System.Drawing.Color.Yellow;
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Location = new System.Drawing.Point(887, 202);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(10, 10);
            this.button170.TabIndex = 355;
            this.button170.UseVisualStyleBackColor = false;
            // 
            // button171
            // 
            this.button171.BackColor = System.Drawing.Color.Yellow;
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Location = new System.Drawing.Point(874, 219);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(10, 10);
            this.button171.TabIndex = 354;
            this.button171.UseVisualStyleBackColor = false;
            // 
            // button172
            // 
            this.button172.BackColor = System.Drawing.Color.Yellow;
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Location = new System.Drawing.Point(874, 202);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(10, 10);
            this.button172.TabIndex = 353;
            this.button172.UseVisualStyleBackColor = false;
            // 
            // button173
            // 
            this.button173.BackColor = System.Drawing.Color.Yellow;
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Location = new System.Drawing.Point(888, 184);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(10, 10);
            this.button173.TabIndex = 352;
            this.button173.UseVisualStyleBackColor = false;
            // 
            // button174
            // 
            this.button174.BackColor = System.Drawing.Color.Yellow;
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Location = new System.Drawing.Point(887, 166);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(10, 10);
            this.button174.TabIndex = 351;
            this.button174.UseVisualStyleBackColor = false;
            // 
            // button175
            // 
            this.button175.BackColor = System.Drawing.Color.Yellow;
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Location = new System.Drawing.Point(874, 184);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(10, 10);
            this.button175.TabIndex = 350;
            this.button175.UseVisualStyleBackColor = false;
            // 
            // button176
            // 
            this.button176.BackColor = System.Drawing.Color.Yellow;
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button176.Location = new System.Drawing.Point(874, 166);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(10, 10);
            this.button176.TabIndex = 349;
            this.button176.UseVisualStyleBackColor = false;
            // 
            // button177
            // 
            this.button177.BackColor = System.Drawing.Color.Yellow;
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Location = new System.Drawing.Point(887, 148);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(10, 10);
            this.button177.TabIndex = 348;
            this.button177.UseVisualStyleBackColor = false;
            // 
            // button178
            // 
            this.button178.BackColor = System.Drawing.Color.Yellow;
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Location = new System.Drawing.Point(887, 130);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(10, 10);
            this.button178.TabIndex = 347;
            this.button178.UseVisualStyleBackColor = false;
            // 
            // button179
            // 
            this.button179.BackColor = System.Drawing.Color.Yellow;
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Location = new System.Drawing.Point(873, 148);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(10, 10);
            this.button179.TabIndex = 346;
            this.button179.UseVisualStyleBackColor = false;
            // 
            // button180
            // 
            this.button180.BackColor = System.Drawing.Color.Yellow;
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Location = new System.Drawing.Point(874, 130);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(10, 10);
            this.button180.TabIndex = 345;
            this.button180.UseVisualStyleBackColor = false;
            // 
            // button181
            // 
            this.button181.BackColor = System.Drawing.Color.Yellow;
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button181.Location = new System.Drawing.Point(928, 220);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(10, 10);
            this.button181.TabIndex = 368;
            this.button181.UseVisualStyleBackColor = false;
            // 
            // button182
            // 
            this.button182.BackColor = System.Drawing.Color.Yellow;
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button182.Location = new System.Drawing.Point(928, 202);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(10, 10);
            this.button182.TabIndex = 367;
            this.button182.UseVisualStyleBackColor = false;
            // 
            // button183
            // 
            this.button183.BackColor = System.Drawing.Color.Yellow;
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button183.Location = new System.Drawing.Point(914, 220);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(10, 10);
            this.button183.TabIndex = 366;
            this.button183.UseVisualStyleBackColor = false;
            // 
            // button184
            // 
            this.button184.BackColor = System.Drawing.Color.Yellow;
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button184.Location = new System.Drawing.Point(915, 202);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(10, 10);
            this.button184.TabIndex = 365;
            this.button184.UseVisualStyleBackColor = false;
            // 
            // button185
            // 
            this.button185.BackColor = System.Drawing.Color.Yellow;
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button185.Location = new System.Drawing.Point(929, 183);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(10, 10);
            this.button185.TabIndex = 364;
            this.button185.UseVisualStyleBackColor = false;
            // 
            // button186
            // 
            this.button186.BackColor = System.Drawing.Color.Yellow;
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button186.Location = new System.Drawing.Point(928, 166);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(10, 10);
            this.button186.TabIndex = 363;
            this.button186.UseVisualStyleBackColor = false;
            // 
            // button187
            // 
            this.button187.BackColor = System.Drawing.Color.Yellow;
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button187.Location = new System.Drawing.Point(915, 183);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(10, 10);
            this.button187.TabIndex = 362;
            this.button187.UseVisualStyleBackColor = false;
            // 
            // button188
            // 
            this.button188.BackColor = System.Drawing.Color.Yellow;
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button188.Location = new System.Drawing.Point(915, 167);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(10, 10);
            this.button188.TabIndex = 361;
            this.button188.UseVisualStyleBackColor = false;
            // 
            // button189
            // 
            this.button189.BackColor = System.Drawing.Color.Yellow;
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button189.Location = new System.Drawing.Point(928, 148);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(10, 10);
            this.button189.TabIndex = 360;
            this.button189.UseVisualStyleBackColor = false;
            // 
            // button190
            // 
            this.button190.BackColor = System.Drawing.Color.Yellow;
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button190.Location = new System.Drawing.Point(928, 130);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(10, 10);
            this.button190.TabIndex = 359;
            this.button190.UseVisualStyleBackColor = false;
            // 
            // button191
            // 
            this.button191.BackColor = System.Drawing.Color.Yellow;
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button191.Location = new System.Drawing.Point(914, 148);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(10, 10);
            this.button191.TabIndex = 358;
            this.button191.UseVisualStyleBackColor = false;
            // 
            // button192
            // 
            this.button192.BackColor = System.Drawing.Color.Yellow;
            this.button192.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button192.Location = new System.Drawing.Point(915, 130);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(10, 10);
            this.button192.TabIndex = 357;
            this.button192.UseVisualStyleBackColor = false;
            // 
            // button193
            // 
            this.button193.BackColor = System.Drawing.Color.Yellow;
            this.button193.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button193.Location = new System.Drawing.Point(806, 221);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(10, 10);
            this.button193.TabIndex = 374;
            this.button193.UseVisualStyleBackColor = false;
            // 
            // button194
            // 
            this.button194.BackColor = System.Drawing.Color.Yellow;
            this.button194.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button194.Location = new System.Drawing.Point(806, 203);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(10, 10);
            this.button194.TabIndex = 373;
            this.button194.UseVisualStyleBackColor = false;
            // 
            // button195
            // 
            this.button195.BackColor = System.Drawing.Color.Yellow;
            this.button195.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button195.Location = new System.Drawing.Point(807, 184);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(10, 10);
            this.button195.TabIndex = 372;
            this.button195.UseVisualStyleBackColor = false;
            // 
            // button196
            // 
            this.button196.BackColor = System.Drawing.Color.Yellow;
            this.button196.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button196.Location = new System.Drawing.Point(806, 167);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(10, 10);
            this.button196.TabIndex = 371;
            this.button196.UseVisualStyleBackColor = false;
            // 
            // button197
            // 
            this.button197.BackColor = System.Drawing.Color.Yellow;
            this.button197.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button197.Location = new System.Drawing.Point(806, 149);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(10, 10);
            this.button197.TabIndex = 370;
            this.button197.UseVisualStyleBackColor = false;
            // 
            // button198
            // 
            this.button198.BackColor = System.Drawing.Color.Yellow;
            this.button198.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button198.Location = new System.Drawing.Point(806, 131);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(10, 10);
            this.button198.TabIndex = 369;
            this.button198.UseVisualStyleBackColor = false;
            // 
            // button199
            // 
            this.button199.BackColor = System.Drawing.Color.Yellow;
            this.button199.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button199.Location = new System.Drawing.Point(956, 220);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(10, 10);
            this.button199.TabIndex = 380;
            this.button199.UseVisualStyleBackColor = false;
            // 
            // button200
            // 
            this.button200.BackColor = System.Drawing.Color.Yellow;
            this.button200.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button200.Location = new System.Drawing.Point(956, 202);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(10, 10);
            this.button200.TabIndex = 379;
            this.button200.UseVisualStyleBackColor = false;
            // 
            // button201
            // 
            this.button201.BackColor = System.Drawing.Color.Yellow;
            this.button201.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button201.Location = new System.Drawing.Point(957, 183);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(10, 10);
            this.button201.TabIndex = 378;
            this.button201.UseVisualStyleBackColor = false;
            // 
            // button202
            // 
            this.button202.BackColor = System.Drawing.Color.Yellow;
            this.button202.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button202.Location = new System.Drawing.Point(956, 166);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(10, 10);
            this.button202.TabIndex = 377;
            this.button202.UseVisualStyleBackColor = false;
            // 
            // button203
            // 
            this.button203.BackColor = System.Drawing.Color.Yellow;
            this.button203.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button203.Location = new System.Drawing.Point(956, 148);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(10, 10);
            this.button203.TabIndex = 376;
            this.button203.UseVisualStyleBackColor = false;
            // 
            // button204
            // 
            this.button204.BackColor = System.Drawing.Color.Yellow;
            this.button204.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button204.Location = new System.Drawing.Point(956, 130);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(10, 10);
            this.button204.TabIndex = 375;
            this.button204.UseVisualStyleBackColor = false;
            // 
            // button205
            // 
            this.button205.BackColor = System.Drawing.Color.Yellow;
            this.button205.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button205.Location = new System.Drawing.Point(845, 221);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(10, 10);
            this.button205.TabIndex = 386;
            this.button205.UseVisualStyleBackColor = false;
            // 
            // button206
            // 
            this.button206.BackColor = System.Drawing.Color.Yellow;
            this.button206.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button206.Location = new System.Drawing.Point(845, 203);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(10, 10);
            this.button206.TabIndex = 385;
            this.button206.UseVisualStyleBackColor = false;
            // 
            // button207
            // 
            this.button207.BackColor = System.Drawing.Color.Yellow;
            this.button207.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button207.Location = new System.Drawing.Point(846, 184);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(10, 10);
            this.button207.TabIndex = 384;
            this.button207.UseVisualStyleBackColor = false;
            // 
            // button208
            // 
            this.button208.BackColor = System.Drawing.Color.Yellow;
            this.button208.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button208.Location = new System.Drawing.Point(845, 167);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(10, 10);
            this.button208.TabIndex = 383;
            this.button208.UseVisualStyleBackColor = false;
            // 
            // button209
            // 
            this.button209.BackColor = System.Drawing.Color.Yellow;
            this.button209.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button209.Location = new System.Drawing.Point(845, 149);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(10, 10);
            this.button209.TabIndex = 382;
            this.button209.UseVisualStyleBackColor = false;
            // 
            // button210
            // 
            this.button210.BackColor = System.Drawing.Color.Yellow;
            this.button210.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button210.Location = new System.Drawing.Point(845, 131);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(10, 10);
            this.button210.TabIndex = 381;
            this.button210.UseVisualStyleBackColor = false;
            // 
            // button211
            // 
            this.button211.BackColor = System.Drawing.Color.Yellow;
            this.button211.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button211.Location = new System.Drawing.Point(737, 292);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(10, 10);
            this.button211.TabIndex = 389;
            this.button211.UseVisualStyleBackColor = false;
            // 
            // button212
            // 
            this.button212.BackColor = System.Drawing.Color.Yellow;
            this.button212.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button212.Location = new System.Drawing.Point(737, 274);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(10, 10);
            this.button212.TabIndex = 388;
            this.button212.UseVisualStyleBackColor = false;
            // 
            // button213
            // 
            this.button213.BackColor = System.Drawing.Color.Yellow;
            this.button213.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button213.Location = new System.Drawing.Point(737, 256);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(10, 10);
            this.button213.TabIndex = 387;
            this.button213.UseVisualStyleBackColor = false;
            // 
            // button214
            // 
            this.button214.BackColor = System.Drawing.Color.Yellow;
            this.button214.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button214.Location = new System.Drawing.Point(764, 292);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(10, 10);
            this.button214.TabIndex = 392;
            this.button214.UseVisualStyleBackColor = false;
            // 
            // button215
            // 
            this.button215.BackColor = System.Drawing.Color.Yellow;
            this.button215.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button215.Location = new System.Drawing.Point(764, 274);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(10, 10);
            this.button215.TabIndex = 391;
            this.button215.UseVisualStyleBackColor = false;
            // 
            // button216
            // 
            this.button216.BackColor = System.Drawing.Color.Yellow;
            this.button216.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button216.Location = new System.Drawing.Point(764, 256);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(10, 10);
            this.button216.TabIndex = 390;
            this.button216.UseVisualStyleBackColor = false;
            // 
            // button217
            // 
            this.button217.BackColor = System.Drawing.Color.Yellow;
            this.button217.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button217.Location = new System.Drawing.Point(778, 292);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(10, 10);
            this.button217.TabIndex = 395;
            this.button217.UseVisualStyleBackColor = false;
            // 
            // button218
            // 
            this.button218.BackColor = System.Drawing.Color.Yellow;
            this.button218.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button218.Location = new System.Drawing.Point(778, 274);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(10, 10);
            this.button218.TabIndex = 394;
            this.button218.UseVisualStyleBackColor = false;
            // 
            // button219
            // 
            this.button219.BackColor = System.Drawing.Color.Yellow;
            this.button219.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button219.Location = new System.Drawing.Point(777, 256);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(10, 10);
            this.button219.TabIndex = 393;
            this.button219.UseVisualStyleBackColor = false;
            // 
            // button220
            // 
            this.button220.BackColor = System.Drawing.Color.Yellow;
            this.button220.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button220.Location = new System.Drawing.Point(846, 292);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(10, 10);
            this.button220.TabIndex = 398;
            this.button220.UseVisualStyleBackColor = false;
            // 
            // button221
            // 
            this.button221.BackColor = System.Drawing.Color.Yellow;
            this.button221.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button221.Location = new System.Drawing.Point(846, 274);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(10, 10);
            this.button221.TabIndex = 397;
            this.button221.UseVisualStyleBackColor = false;
            // 
            // button222
            // 
            this.button222.BackColor = System.Drawing.Color.Yellow;
            this.button222.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button222.Location = new System.Drawing.Point(846, 256);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(10, 10);
            this.button222.TabIndex = 396;
            this.button222.UseVisualStyleBackColor = false;
            // 
            // button223
            // 
            this.button223.BackColor = System.Drawing.Color.Yellow;
            this.button223.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button223.Location = new System.Drawing.Point(873, 292);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(10, 10);
            this.button223.TabIndex = 401;
            this.button223.UseVisualStyleBackColor = false;
            // 
            // button224
            // 
            this.button224.BackColor = System.Drawing.Color.Yellow;
            this.button224.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button224.Location = new System.Drawing.Point(874, 274);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(10, 10);
            this.button224.TabIndex = 400;
            this.button224.UseVisualStyleBackColor = false;
            // 
            // button225
            // 
            this.button225.BackColor = System.Drawing.Color.Yellow;
            this.button225.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button225.Location = new System.Drawing.Point(874, 256);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(10, 10);
            this.button225.TabIndex = 399;
            this.button225.UseVisualStyleBackColor = false;
            // 
            // button226
            // 
            this.button226.BackColor = System.Drawing.Color.Yellow;
            this.button226.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button226.Location = new System.Drawing.Point(887, 292);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(10, 10);
            this.button226.TabIndex = 404;
            this.button226.UseVisualStyleBackColor = false;
            // 
            // button227
            // 
            this.button227.BackColor = System.Drawing.Color.Yellow;
            this.button227.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button227.Location = new System.Drawing.Point(887, 274);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(10, 10);
            this.button227.TabIndex = 403;
            this.button227.UseVisualStyleBackColor = false;
            // 
            // button228
            // 
            this.button228.BackColor = System.Drawing.Color.Yellow;
            this.button228.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button228.Location = new System.Drawing.Point(887, 256);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(10, 10);
            this.button228.TabIndex = 402;
            this.button228.UseVisualStyleBackColor = false;
            // 
            // button229
            // 
            this.button229.BackColor = System.Drawing.Color.Yellow;
            this.button229.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button229.Location = new System.Drawing.Point(915, 292);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(10, 10);
            this.button229.TabIndex = 407;
            this.button229.UseVisualStyleBackColor = false;
            // 
            // button230
            // 
            this.button230.BackColor = System.Drawing.Color.Yellow;
            this.button230.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button230.Location = new System.Drawing.Point(915, 274);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(10, 10);
            this.button230.TabIndex = 406;
            this.button230.UseVisualStyleBackColor = false;
            // 
            // button231
            // 
            this.button231.BackColor = System.Drawing.Color.Yellow;
            this.button231.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button231.Location = new System.Drawing.Point(915, 256);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(10, 10);
            this.button231.TabIndex = 405;
            this.button231.UseVisualStyleBackColor = false;
            // 
            // button232
            // 
            this.button232.BackColor = System.Drawing.Color.Yellow;
            this.button232.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button232.Location = new System.Drawing.Point(928, 292);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(10, 10);
            this.button232.TabIndex = 410;
            this.button232.UseVisualStyleBackColor = false;
            // 
            // button233
            // 
            this.button233.BackColor = System.Drawing.Color.Yellow;
            this.button233.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button233.Location = new System.Drawing.Point(928, 274);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(10, 10);
            this.button233.TabIndex = 409;
            this.button233.UseVisualStyleBackColor = false;
            // 
            // button234
            // 
            this.button234.BackColor = System.Drawing.Color.Yellow;
            this.button234.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button234.Location = new System.Drawing.Point(928, 256);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(10, 10);
            this.button234.TabIndex = 408;
            this.button234.UseVisualStyleBackColor = false;
            // 
            // button235
            // 
            this.button235.BackColor = System.Drawing.Color.Yellow;
            this.button235.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button235.Location = new System.Drawing.Point(679, 291);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(10, 10);
            this.button235.TabIndex = 411;
            this.button235.UseVisualStyleBackColor = false;
            // 
            // button236
            // 
            this.button236.BackColor = System.Drawing.Color.Yellow;
            this.button236.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button236.Location = new System.Drawing.Point(959, 292);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(10, 10);
            this.button236.TabIndex = 412;
            this.button236.UseVisualStyleBackColor = false;
            // 
            // button237
            // 
            this.button237.BackColor = System.Drawing.Color.Yellow;
            this.button237.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button237.Location = new System.Drawing.Point(463, 385);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(10, 10);
            this.button237.TabIndex = 419;
            this.button237.UseVisualStyleBackColor = false;
            // 
            // button238
            // 
            this.button238.BackColor = System.Drawing.Color.Yellow;
            this.button238.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button238.Location = new System.Drawing.Point(446, 385);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(10, 10);
            this.button238.TabIndex = 418;
            this.button238.UseVisualStyleBackColor = false;
            // 
            // button239
            // 
            this.button239.BackColor = System.Drawing.Color.Yellow;
            this.button239.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button239.Location = new System.Drawing.Point(430, 385);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(10, 10);
            this.button239.TabIndex = 417;
            this.button239.UseVisualStyleBackColor = false;
            // 
            // button240
            // 
            this.button240.BackColor = System.Drawing.Color.Yellow;
            this.button240.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button240.Location = new System.Drawing.Point(413, 385);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(10, 10);
            this.button240.TabIndex = 416;
            this.button240.UseVisualStyleBackColor = false;
            // 
            // button241
            // 
            this.button241.BackColor = System.Drawing.Color.Yellow;
            this.button241.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button241.Location = new System.Drawing.Point(396, 385);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(10, 10);
            this.button241.TabIndex = 415;
            this.button241.UseVisualStyleBackColor = false;
            // 
            // button242
            // 
            this.button242.BackColor = System.Drawing.Color.Yellow;
            this.button242.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button242.Location = new System.Drawing.Point(379, 385);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(10, 10);
            this.button242.TabIndex = 414;
            this.button242.UseVisualStyleBackColor = false;
            // 
            // button243
            // 
            this.button243.BackColor = System.Drawing.Color.Yellow;
            this.button243.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button243.Location = new System.Drawing.Point(362, 385);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(10, 10);
            this.button243.TabIndex = 413;
            this.button243.UseVisualStyleBackColor = false;
            // 
            // button244
            // 
            this.button244.BackColor = System.Drawing.Color.Yellow;
            this.button244.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button244.Location = new System.Drawing.Point(463, 424);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(10, 10);
            this.button244.TabIndex = 426;
            this.button244.UseVisualStyleBackColor = false;
            // 
            // button245
            // 
            this.button245.BackColor = System.Drawing.Color.Yellow;
            this.button245.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button245.Location = new System.Drawing.Point(446, 424);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(10, 10);
            this.button245.TabIndex = 425;
            this.button245.UseVisualStyleBackColor = false;
            // 
            // button246
            // 
            this.button246.BackColor = System.Drawing.Color.Yellow;
            this.button246.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button246.Location = new System.Drawing.Point(430, 424);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(10, 10);
            this.button246.TabIndex = 424;
            this.button246.UseVisualStyleBackColor = false;
            // 
            // button247
            // 
            this.button247.BackColor = System.Drawing.Color.Yellow;
            this.button247.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button247.Location = new System.Drawing.Point(412, 425);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(10, 10);
            this.button247.TabIndex = 423;
            this.button247.UseVisualStyleBackColor = false;
            // 
            // button248
            // 
            this.button248.BackColor = System.Drawing.Color.Yellow;
            this.button248.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button248.Location = new System.Drawing.Point(395, 425);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(10, 10);
            this.button248.TabIndex = 422;
            this.button248.UseVisualStyleBackColor = false;
            // 
            // button249
            // 
            this.button249.BackColor = System.Drawing.Color.Yellow;
            this.button249.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button249.Location = new System.Drawing.Point(378, 425);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(10, 10);
            this.button249.TabIndex = 421;
            this.button249.UseVisualStyleBackColor = false;
            // 
            // button250
            // 
            this.button250.BackColor = System.Drawing.Color.Yellow;
            this.button250.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button250.Location = new System.Drawing.Point(361, 425);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(10, 10);
            this.button250.TabIndex = 420;
            this.button250.UseVisualStyleBackColor = false;
            // 
            // button251
            // 
            this.button251.BackColor = System.Drawing.Color.Yellow;
            this.button251.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button251.Location = new System.Drawing.Point(463, 465);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(10, 10);
            this.button251.TabIndex = 433;
            this.button251.UseVisualStyleBackColor = false;
            // 
            // button252
            // 
            this.button252.BackColor = System.Drawing.Color.Yellow;
            this.button252.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button252.Location = new System.Drawing.Point(446, 465);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(10, 10);
            this.button252.TabIndex = 432;
            this.button252.UseVisualStyleBackColor = false;
            // 
            // button253
            // 
            this.button253.BackColor = System.Drawing.Color.Yellow;
            this.button253.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button253.Location = new System.Drawing.Point(430, 465);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(10, 10);
            this.button253.TabIndex = 431;
            this.button253.UseVisualStyleBackColor = false;
            // 
            // button254
            // 
            this.button254.BackColor = System.Drawing.Color.Yellow;
            this.button254.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button254.Location = new System.Drawing.Point(413, 465);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(10, 10);
            this.button254.TabIndex = 430;
            this.button254.UseVisualStyleBackColor = false;
            // 
            // button255
            // 
            this.button255.BackColor = System.Drawing.Color.Yellow;
            this.button255.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button255.Location = new System.Drawing.Point(396, 465);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(10, 10);
            this.button255.TabIndex = 429;
            this.button255.UseVisualStyleBackColor = false;
            // 
            // button256
            // 
            this.button256.BackColor = System.Drawing.Color.Yellow;
            this.button256.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button256.Location = new System.Drawing.Point(379, 465);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(10, 10);
            this.button256.TabIndex = 428;
            this.button256.UseVisualStyleBackColor = false;
            // 
            // button257
            // 
            this.button257.BackColor = System.Drawing.Color.Yellow;
            this.button257.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button257.Location = new System.Drawing.Point(362, 465);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(10, 10);
            this.button257.TabIndex = 427;
            this.button257.UseVisualStyleBackColor = false;
            // 
            // button258
            // 
            this.button258.BackColor = System.Drawing.Color.Yellow;
            this.button258.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button258.Location = new System.Drawing.Point(479, 385);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(10, 10);
            this.button258.TabIndex = 434;
            this.button258.UseVisualStyleBackColor = false;
            // 
            // button259
            // 
            this.button259.BackColor = System.Drawing.Color.Yellow;
            this.button259.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button259.Location = new System.Drawing.Point(495, 385);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(10, 10);
            this.button259.TabIndex = 435;
            this.button259.UseVisualStyleBackColor = false;
            // 
            // button260
            // 
            this.button260.BackColor = System.Drawing.Color.Yellow;
            this.button260.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button260.Location = new System.Drawing.Point(479, 425);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(10, 10);
            this.button260.TabIndex = 436;
            this.button260.UseVisualStyleBackColor = false;
            // 
            // button261
            // 
            this.button261.BackColor = System.Drawing.Color.Yellow;
            this.button261.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button261.Location = new System.Drawing.Point(479, 465);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(10, 10);
            this.button261.TabIndex = 437;
            this.button261.UseVisualStyleBackColor = false;
            // 
            // button262
            // 
            this.button262.BackColor = System.Drawing.Color.Yellow;
            this.button262.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button262.Location = new System.Drawing.Point(501, 441);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(10, 10);
            this.button262.TabIndex = 438;
            this.button262.UseVisualStyleBackColor = false;
            // 
            // button263
            // 
            this.button263.BackColor = System.Drawing.Color.Yellow;
            this.button263.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button263.Location = new System.Drawing.Point(462, 505);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(10, 10);
            this.button263.TabIndex = 444;
            this.button263.UseVisualStyleBackColor = false;
            // 
            // button264
            // 
            this.button264.BackColor = System.Drawing.Color.Yellow;
            this.button264.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button264.Location = new System.Drawing.Point(446, 505);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(10, 10);
            this.button264.TabIndex = 443;
            this.button264.UseVisualStyleBackColor = false;
            // 
            // button265
            // 
            this.button265.BackColor = System.Drawing.Color.Yellow;
            this.button265.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button265.Location = new System.Drawing.Point(429, 505);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(10, 10);
            this.button265.TabIndex = 442;
            this.button265.UseVisualStyleBackColor = false;
            // 
            // button266
            // 
            this.button266.BackColor = System.Drawing.Color.Yellow;
            this.button266.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button266.Location = new System.Drawing.Point(413, 505);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(10, 10);
            this.button266.TabIndex = 441;
            this.button266.UseVisualStyleBackColor = false;
            // 
            // button267
            // 
            this.button267.BackColor = System.Drawing.Color.Yellow;
            this.button267.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button267.Location = new System.Drawing.Point(396, 505);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(10, 10);
            this.button267.TabIndex = 440;
            this.button267.UseVisualStyleBackColor = false;
            // 
            // button268
            // 
            this.button268.BackColor = System.Drawing.Color.Yellow;
            this.button268.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button268.Location = new System.Drawing.Point(379, 505);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(10, 10);
            this.button268.TabIndex = 439;
            this.button268.UseVisualStyleBackColor = false;
            // 
            // button269
            // 
            this.button269.BackColor = System.Drawing.Color.Yellow;
            this.button269.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button269.Location = new System.Drawing.Point(361, 505);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(10, 10);
            this.button269.TabIndex = 445;
            this.button269.UseVisualStyleBackColor = false;
            // 
            // button270
            // 
            this.button270.BackColor = System.Drawing.Color.Yellow;
            this.button270.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button270.Location = new System.Drawing.Point(1228, 149);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(10, 10);
            this.button270.TabIndex = 456;
            this.button270.UseVisualStyleBackColor = false;
            // 
            // button271
            // 
            this.button271.BackColor = System.Drawing.Color.Yellow;
            this.button271.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button271.Location = new System.Drawing.Point(1211, 149);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(10, 10);
            this.button271.TabIndex = 455;
            this.button271.UseVisualStyleBackColor = false;
            // 
            // button272
            // 
            this.button272.BackColor = System.Drawing.Color.Yellow;
            this.button272.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button272.Location = new System.Drawing.Point(1194, 148);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(10, 10);
            this.button272.TabIndex = 454;
            this.button272.UseVisualStyleBackColor = false;
            // 
            // button273
            // 
            this.button273.BackColor = System.Drawing.Color.Yellow;
            this.button273.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button273.Location = new System.Drawing.Point(1177, 148);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(10, 10);
            this.button273.TabIndex = 453;
            this.button273.UseVisualStyleBackColor = false;
            // 
            // button274
            // 
            this.button274.BackColor = System.Drawing.Color.Yellow;
            this.button274.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button274.Location = new System.Drawing.Point(1160, 149);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(10, 10);
            this.button274.TabIndex = 452;
            this.button274.UseVisualStyleBackColor = false;
            // 
            // button275
            // 
            this.button275.BackColor = System.Drawing.Color.Yellow;
            this.button275.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button275.Location = new System.Drawing.Point(1143, 148);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(10, 10);
            this.button275.TabIndex = 451;
            this.button275.UseVisualStyleBackColor = false;
            // 
            // button276
            // 
            this.button276.BackColor = System.Drawing.Color.Yellow;
            this.button276.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button276.Location = new System.Drawing.Point(1127, 149);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(10, 10);
            this.button276.TabIndex = 450;
            this.button276.UseVisualStyleBackColor = false;
            // 
            // button277
            // 
            this.button277.BackColor = System.Drawing.Color.Yellow;
            this.button277.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button277.Location = new System.Drawing.Point(1110, 149);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(10, 10);
            this.button277.TabIndex = 449;
            this.button277.UseVisualStyleBackColor = false;
            // 
            // button278
            // 
            this.button278.BackColor = System.Drawing.Color.Yellow;
            this.button278.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button278.Location = new System.Drawing.Point(1093, 148);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(10, 10);
            this.button278.TabIndex = 448;
            this.button278.UseVisualStyleBackColor = false;
            // 
            // button279
            // 
            this.button279.BackColor = System.Drawing.Color.Yellow;
            this.button279.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button279.Location = new System.Drawing.Point(1077, 149);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(10, 10);
            this.button279.TabIndex = 447;
            this.button279.UseVisualStyleBackColor = false;
            // 
            // button280
            // 
            this.button280.BackColor = System.Drawing.Color.Yellow;
            this.button280.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button280.Location = new System.Drawing.Point(1059, 148);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(10, 10);
            this.button280.TabIndex = 446;
            this.button280.UseVisualStyleBackColor = false;
            // 
            // button281
            // 
            this.button281.BackColor = System.Drawing.Color.Yellow;
            this.button281.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button281.Location = new System.Drawing.Point(1227, 202);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(10, 10);
            this.button281.TabIndex = 467;
            this.button281.UseVisualStyleBackColor = false;
            // 
            // button282
            // 
            this.button282.BackColor = System.Drawing.Color.Yellow;
            this.button282.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button282.Location = new System.Drawing.Point(1210, 202);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(10, 10);
            this.button282.TabIndex = 466;
            this.button282.UseVisualStyleBackColor = false;
            // 
            // button283
            // 
            this.button283.BackColor = System.Drawing.Color.Yellow;
            this.button283.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button283.Location = new System.Drawing.Point(1193, 201);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(10, 10);
            this.button283.TabIndex = 465;
            this.button283.UseVisualStyleBackColor = false;
            // 
            // button284
            // 
            this.button284.BackColor = System.Drawing.Color.Yellow;
            this.button284.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button284.Location = new System.Drawing.Point(1177, 202);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(10, 10);
            this.button284.TabIndex = 464;
            this.button284.UseVisualStyleBackColor = false;
            // 
            // button285
            // 
            this.button285.BackColor = System.Drawing.Color.Yellow;
            this.button285.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button285.Location = new System.Drawing.Point(1160, 202);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(10, 10);
            this.button285.TabIndex = 463;
            this.button285.UseVisualStyleBackColor = false;
            // 
            // button286
            // 
            this.button286.BackColor = System.Drawing.Color.Yellow;
            this.button286.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button286.Location = new System.Drawing.Point(1143, 202);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(10, 10);
            this.button286.TabIndex = 462;
            this.button286.UseVisualStyleBackColor = false;
            // 
            // button287
            // 
            this.button287.BackColor = System.Drawing.Color.Yellow;
            this.button287.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button287.Location = new System.Drawing.Point(1126, 203);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(10, 10);
            this.button287.TabIndex = 461;
            this.button287.UseVisualStyleBackColor = false;
            // 
            // button288
            // 
            this.button288.BackColor = System.Drawing.Color.Yellow;
            this.button288.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button288.Location = new System.Drawing.Point(1110, 203);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(10, 10);
            this.button288.TabIndex = 460;
            this.button288.UseVisualStyleBackColor = false;
            // 
            // button289
            // 
            this.button289.BackColor = System.Drawing.Color.Yellow;
            this.button289.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button289.Location = new System.Drawing.Point(1093, 202);
            this.button289.Name = "button289";
            this.button289.Size = new System.Drawing.Size(10, 10);
            this.button289.TabIndex = 459;
            this.button289.UseVisualStyleBackColor = false;
            // 
            // button290
            // 
            this.button290.BackColor = System.Drawing.Color.Yellow;
            this.button290.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button290.Location = new System.Drawing.Point(1075, 202);
            this.button290.Name = "button290";
            this.button290.Size = new System.Drawing.Size(10, 10);
            this.button290.TabIndex = 458;
            this.button290.UseVisualStyleBackColor = false;
            // 
            // button291
            // 
            this.button291.BackColor = System.Drawing.Color.Yellow;
            this.button291.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button291.Location = new System.Drawing.Point(1058, 201);
            this.button291.Name = "button291";
            this.button291.Size = new System.Drawing.Size(10, 10);
            this.button291.TabIndex = 457;
            this.button291.UseVisualStyleBackColor = false;
            // 
            // button292
            // 
            this.button292.BackColor = System.Drawing.Color.Yellow;
            this.button292.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button292.Location = new System.Drawing.Point(1227, 216);
            this.button292.Name = "button292";
            this.button292.Size = new System.Drawing.Size(10, 10);
            this.button292.TabIndex = 478;
            this.button292.UseVisualStyleBackColor = false;
            // 
            // button293
            // 
            this.button293.BackColor = System.Drawing.Color.Yellow;
            this.button293.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button293.Location = new System.Drawing.Point(1210, 216);
            this.button293.Name = "button293";
            this.button293.Size = new System.Drawing.Size(10, 10);
            this.button293.TabIndex = 477;
            this.button293.UseVisualStyleBackColor = false;
            // 
            // button294
            // 
            this.button294.BackColor = System.Drawing.Color.Yellow;
            this.button294.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button294.Location = new System.Drawing.Point(1193, 216);
            this.button294.Name = "button294";
            this.button294.Size = new System.Drawing.Size(10, 10);
            this.button294.TabIndex = 476;
            this.button294.UseVisualStyleBackColor = false;
            // 
            // button295
            // 
            this.button295.BackColor = System.Drawing.Color.Yellow;
            this.button295.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button295.Location = new System.Drawing.Point(1176, 216);
            this.button295.Name = "button295";
            this.button295.Size = new System.Drawing.Size(10, 10);
            this.button295.TabIndex = 475;
            this.button295.UseVisualStyleBackColor = false;
            // 
            // button296
            // 
            this.button296.BackColor = System.Drawing.Color.Yellow;
            this.button296.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button296.Location = new System.Drawing.Point(1159, 216);
            this.button296.Name = "button296";
            this.button296.Size = new System.Drawing.Size(10, 10);
            this.button296.TabIndex = 474;
            this.button296.UseVisualStyleBackColor = false;
            // 
            // button297
            // 
            this.button297.BackColor = System.Drawing.Color.Yellow;
            this.button297.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button297.Location = new System.Drawing.Point(1142, 216);
            this.button297.Name = "button297";
            this.button297.Size = new System.Drawing.Size(10, 10);
            this.button297.TabIndex = 473;
            this.button297.UseVisualStyleBackColor = false;
            // 
            // button298
            // 
            this.button298.BackColor = System.Drawing.Color.Yellow;
            this.button298.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button298.Location = new System.Drawing.Point(1126, 216);
            this.button298.Name = "button298";
            this.button298.Size = new System.Drawing.Size(10, 10);
            this.button298.TabIndex = 472;
            this.button298.UseVisualStyleBackColor = false;
            // 
            // button299
            // 
            this.button299.BackColor = System.Drawing.Color.Yellow;
            this.button299.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button299.Location = new System.Drawing.Point(1109, 216);
            this.button299.Name = "button299";
            this.button299.Size = new System.Drawing.Size(10, 10);
            this.button299.TabIndex = 471;
            this.button299.UseVisualStyleBackColor = false;
            // 
            // button300
            // 
            this.button300.BackColor = System.Drawing.Color.Yellow;
            this.button300.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button300.Location = new System.Drawing.Point(1093, 215);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(10, 10);
            this.button300.TabIndex = 470;
            this.button300.UseVisualStyleBackColor = false;
            // 
            // button301
            // 
            this.button301.BackColor = System.Drawing.Color.Yellow;
            this.button301.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button301.Location = new System.Drawing.Point(1075, 215);
            this.button301.Name = "button301";
            this.button301.Size = new System.Drawing.Size(10, 10);
            this.button301.TabIndex = 469;
            this.button301.UseVisualStyleBackColor = false;
            // 
            // button302
            // 
            this.button302.BackColor = System.Drawing.Color.Yellow;
            this.button302.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button302.Location = new System.Drawing.Point(1058, 215);
            this.button302.Name = "button302";
            this.button302.Size = new System.Drawing.Size(10, 10);
            this.button302.TabIndex = 468;
            this.button302.UseVisualStyleBackColor = false;
            // 
            // button303
            // 
            this.button303.BackColor = System.Drawing.Color.Yellow;
            this.button303.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button303.Location = new System.Drawing.Point(1227, 274);
            this.button303.Name = "button303";
            this.button303.Size = new System.Drawing.Size(10, 10);
            this.button303.TabIndex = 489;
            this.button303.UseVisualStyleBackColor = false;
            // 
            // button304
            // 
            this.button304.BackColor = System.Drawing.Color.Yellow;
            this.button304.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button304.Location = new System.Drawing.Point(1210, 274);
            this.button304.Name = "button304";
            this.button304.Size = new System.Drawing.Size(10, 10);
            this.button304.TabIndex = 488;
            this.button304.UseVisualStyleBackColor = false;
            // 
            // button305
            // 
            this.button305.BackColor = System.Drawing.Color.Yellow;
            this.button305.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button305.Location = new System.Drawing.Point(1193, 273);
            this.button305.Name = "button305";
            this.button305.Size = new System.Drawing.Size(10, 10);
            this.button305.TabIndex = 487;
            this.button305.UseVisualStyleBackColor = false;
            // 
            // button306
            // 
            this.button306.BackColor = System.Drawing.Color.Yellow;
            this.button306.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button306.Location = new System.Drawing.Point(1176, 273);
            this.button306.Name = "button306";
            this.button306.Size = new System.Drawing.Size(10, 10);
            this.button306.TabIndex = 486;
            this.button306.UseVisualStyleBackColor = false;
            // 
            // button307
            // 
            this.button307.BackColor = System.Drawing.Color.Yellow;
            this.button307.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button307.Location = new System.Drawing.Point(1159, 274);
            this.button307.Name = "button307";
            this.button307.Size = new System.Drawing.Size(10, 10);
            this.button307.TabIndex = 485;
            this.button307.UseVisualStyleBackColor = false;
            // 
            // button308
            // 
            this.button308.BackColor = System.Drawing.Color.Yellow;
            this.button308.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button308.Location = new System.Drawing.Point(1142, 273);
            this.button308.Name = "button308";
            this.button308.Size = new System.Drawing.Size(10, 10);
            this.button308.TabIndex = 484;
            this.button308.UseVisualStyleBackColor = false;
            // 
            // button309
            // 
            this.button309.BackColor = System.Drawing.Color.Yellow;
            this.button309.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button309.Location = new System.Drawing.Point(1125, 274);
            this.button309.Name = "button309";
            this.button309.Size = new System.Drawing.Size(10, 10);
            this.button309.TabIndex = 483;
            this.button309.UseVisualStyleBackColor = false;
            // 
            // button310
            // 
            this.button310.BackColor = System.Drawing.Color.Yellow;
            this.button310.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button310.Location = new System.Drawing.Point(1108, 274);
            this.button310.Name = "button310";
            this.button310.Size = new System.Drawing.Size(10, 10);
            this.button310.TabIndex = 482;
            this.button310.UseVisualStyleBackColor = false;
            // 
            // button311
            // 
            this.button311.BackColor = System.Drawing.Color.Yellow;
            this.button311.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button311.Location = new System.Drawing.Point(1092, 273);
            this.button311.Name = "button311";
            this.button311.Size = new System.Drawing.Size(10, 10);
            this.button311.TabIndex = 481;
            this.button311.UseVisualStyleBackColor = false;
            // 
            // button312
            // 
            this.button312.BackColor = System.Drawing.Color.Yellow;
            this.button312.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button312.Location = new System.Drawing.Point(1075, 274);
            this.button312.Name = "button312";
            this.button312.Size = new System.Drawing.Size(10, 10);
            this.button312.TabIndex = 480;
            this.button312.UseVisualStyleBackColor = false;
            // 
            // button313
            // 
            this.button313.BackColor = System.Drawing.Color.Yellow;
            this.button313.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button313.Location = new System.Drawing.Point(1058, 274);
            this.button313.Name = "button313";
            this.button313.Size = new System.Drawing.Size(10, 10);
            this.button313.TabIndex = 479;
            this.button313.UseVisualStyleBackColor = false;
            // 
            // MachinesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1370, 665);
            this.Controls.Add(this.button303);
            this.Controls.Add(this.button304);
            this.Controls.Add(this.button305);
            this.Controls.Add(this.button306);
            this.Controls.Add(this.button307);
            this.Controls.Add(this.button308);
            this.Controls.Add(this.button309);
            this.Controls.Add(this.button310);
            this.Controls.Add(this.button311);
            this.Controls.Add(this.button312);
            this.Controls.Add(this.button313);
            this.Controls.Add(this.button292);
            this.Controls.Add(this.button293);
            this.Controls.Add(this.button294);
            this.Controls.Add(this.button295);
            this.Controls.Add(this.button296);
            this.Controls.Add(this.button297);
            this.Controls.Add(this.button298);
            this.Controls.Add(this.button299);
            this.Controls.Add(this.button300);
            this.Controls.Add(this.button301);
            this.Controls.Add(this.button302);
            this.Controls.Add(this.button281);
            this.Controls.Add(this.button282);
            this.Controls.Add(this.button283);
            this.Controls.Add(this.button284);
            this.Controls.Add(this.button285);
            this.Controls.Add(this.button286);
            this.Controls.Add(this.button287);
            this.Controls.Add(this.button288);
            this.Controls.Add(this.button289);
            this.Controls.Add(this.button290);
            this.Controls.Add(this.button291);
            this.Controls.Add(this.button270);
            this.Controls.Add(this.button271);
            this.Controls.Add(this.button272);
            this.Controls.Add(this.button273);
            this.Controls.Add(this.button274);
            this.Controls.Add(this.button275);
            this.Controls.Add(this.button276);
            this.Controls.Add(this.button277);
            this.Controls.Add(this.button278);
            this.Controls.Add(this.button279);
            this.Controls.Add(this.button280);
            this.Controls.Add(this.button269);
            this.Controls.Add(this.button263);
            this.Controls.Add(this.button264);
            this.Controls.Add(this.button265);
            this.Controls.Add(this.button266);
            this.Controls.Add(this.button267);
            this.Controls.Add(this.button268);
            this.Controls.Add(this.button262);
            this.Controls.Add(this.button261);
            this.Controls.Add(this.button260);
            this.Controls.Add(this.button259);
            this.Controls.Add(this.button258);
            this.Controls.Add(this.button251);
            this.Controls.Add(this.button252);
            this.Controls.Add(this.button253);
            this.Controls.Add(this.button254);
            this.Controls.Add(this.button255);
            this.Controls.Add(this.button256);
            this.Controls.Add(this.button257);
            this.Controls.Add(this.button244);
            this.Controls.Add(this.button245);
            this.Controls.Add(this.button246);
            this.Controls.Add(this.button247);
            this.Controls.Add(this.button248);
            this.Controls.Add(this.button249);
            this.Controls.Add(this.button250);
            this.Controls.Add(this.button237);
            this.Controls.Add(this.button238);
            this.Controls.Add(this.button239);
            this.Controls.Add(this.button240);
            this.Controls.Add(this.button241);
            this.Controls.Add(this.button242);
            this.Controls.Add(this.button243);
            this.Controls.Add(this.button236);
            this.Controls.Add(this.button235);
            this.Controls.Add(this.button232);
            this.Controls.Add(this.button233);
            this.Controls.Add(this.button234);
            this.Controls.Add(this.button229);
            this.Controls.Add(this.button230);
            this.Controls.Add(this.button231);
            this.Controls.Add(this.button226);
            this.Controls.Add(this.button227);
            this.Controls.Add(this.button228);
            this.Controls.Add(this.button223);
            this.Controls.Add(this.button224);
            this.Controls.Add(this.button225);
            this.Controls.Add(this.button220);
            this.Controls.Add(this.button221);
            this.Controls.Add(this.button222);
            this.Controls.Add(this.button217);
            this.Controls.Add(this.button218);
            this.Controls.Add(this.button219);
            this.Controls.Add(this.button214);
            this.Controls.Add(this.button215);
            this.Controls.Add(this.button216);
            this.Controls.Add(this.button211);
            this.Controls.Add(this.button212);
            this.Controls.Add(this.button213);
            this.Controls.Add(this.button205);
            this.Controls.Add(this.button206);
            this.Controls.Add(this.button207);
            this.Controls.Add(this.button208);
            this.Controls.Add(this.button209);
            this.Controls.Add(this.button210);
            this.Controls.Add(this.button199);
            this.Controls.Add(this.button200);
            this.Controls.Add(this.button201);
            this.Controls.Add(this.button202);
            this.Controls.Add(this.button203);
            this.Controls.Add(this.button204);
            this.Controls.Add(this.button193);
            this.Controls.Add(this.button194);
            this.Controls.Add(this.button195);
            this.Controls.Add(this.button196);
            this.Controls.Add(this.button197);
            this.Controls.Add(this.button198);
            this.Controls.Add(this.button181);
            this.Controls.Add(this.button182);
            this.Controls.Add(this.button183);
            this.Controls.Add(this.button184);
            this.Controls.Add(this.button185);
            this.Controls.Add(this.button186);
            this.Controls.Add(this.button187);
            this.Controls.Add(this.button188);
            this.Controls.Add(this.button189);
            this.Controls.Add(this.button190);
            this.Controls.Add(this.button191);
            this.Controls.Add(this.button192);
            this.Controls.Add(this.button169);
            this.Controls.Add(this.button170);
            this.Controls.Add(this.button171);
            this.Controls.Add(this.button172);
            this.Controls.Add(this.button173);
            this.Controls.Add(this.button174);
            this.Controls.Add(this.button175);
            this.Controls.Add(this.button176);
            this.Controls.Add(this.button177);
            this.Controls.Add(this.button178);
            this.Controls.Add(this.button179);
            this.Controls.Add(this.button180);
            this.Controls.Add(this.button155);
            this.Controls.Add(this.button157);
            this.Controls.Add(this.button159);
            this.Controls.Add(this.button160);
            this.Controls.Add(this.button161);
            this.Controls.Add(this.button162);
            this.Controls.Add(this.button163);
            this.Controls.Add(this.button164);
            this.Controls.Add(this.button165);
            this.Controls.Add(this.button166);
            this.Controls.Add(this.button167);
            this.Controls.Add(this.button168);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.button148);
            this.Controls.Add(this.button149);
            this.Controls.Add(this.button150);
            this.Controls.Add(this.button147);
            this.Controls.Add(this.button141);
            this.Controls.Add(this.button142);
            this.Controls.Add(this.button143);
            this.Controls.Add(this.button144);
            this.Controls.Add(this.button145);
            this.Controls.Add(this.button146);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button136);
            this.Controls.Add(this.button137);
            this.Controls.Add(this.button138);
            this.Controls.Add(this.button139);
            this.Controls.Add(this.button140);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.button134);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button156);
            this.Controls.Add(this.button158);
            this.Controls.Add(this.button154);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MachinesForm";
            this.Load += new System.EventHandler(this.MachinesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button289;
        private System.Windows.Forms.Button button290;
        private System.Windows.Forms.Button button291;
        private System.Windows.Forms.Button button292;
        private System.Windows.Forms.Button button293;
        private System.Windows.Forms.Button button294;
        private System.Windows.Forms.Button button295;
        private System.Windows.Forms.Button button296;
        private System.Windows.Forms.Button button297;
        private System.Windows.Forms.Button button298;
        private System.Windows.Forms.Button button299;
        private System.Windows.Forms.Button button300;
        private System.Windows.Forms.Button button301;
        private System.Windows.Forms.Button button302;
        private System.Windows.Forms.Button button303;
        private System.Windows.Forms.Button button304;
        private System.Windows.Forms.Button button305;
        private System.Windows.Forms.Button button306;
        private System.Windows.Forms.Button button307;
        private System.Windows.Forms.Button button308;
        private System.Windows.Forms.Button button309;
        private System.Windows.Forms.Button button310;
        private System.Windows.Forms.Button button311;
        private System.Windows.Forms.Button button312;
        private System.Windows.Forms.Button button313;
    }
}