﻿namespace Lab_And_Tutor_Finder_System
{
    partial class MachinesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MachinesForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button139 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button143 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button146 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Lab_And_Tutor_Finder_System.Properties.Resources.Floor_plan_1;
            this.pictureBox1.Location = new System.Drawing.Point(34, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(956, 562);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.Yellow;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(766, 57);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 16);
            this.button10.TabIndex = 15;
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Yellow;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(737, 57);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(30, 16);
            this.button11.TabIndex = 14;
            this.button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Lime;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(708, 57);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 16);
            this.button12.TabIndex = 13;
            this.button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button12.UseVisualStyleBackColor = false;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Lime;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(679, 57);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(30, 16);
            this.button13.TabIndex = 12;
            this.button13.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.Yellow;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(656, 57);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(30, 16);
            this.button14.TabIndex = 11;
            this.button14.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button14.UseVisualStyleBackColor = false;
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.Lime;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(628, 57);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 16);
            this.button15.TabIndex = 10;
            this.button15.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button15.UseVisualStyleBackColor = false;
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.Lime;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(715, 144);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(34, 20);
            this.button22.TabIndex = 33;
            this.button22.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button22.UseVisualStyleBackColor = false;
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.Color.Yellow;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(689, 144);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(27, 20);
            this.button23.TabIndex = 32;
            this.button23.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button23.UseVisualStyleBackColor = false;
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.Color.Yellow;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(663, 144);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(27, 20);
            this.button24.TabIndex = 31;
            this.button24.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button24.UseVisualStyleBackColor = false;
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.Color.Yellow;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(637, 144);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(27, 20);
            this.button28.TabIndex = 30;
            this.button28.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button28.UseVisualStyleBackColor = false;
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.Color.Lime;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(611, 144);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(27, 20);
            this.button29.TabIndex = 29;
            this.button29.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button29.UseVisualStyleBackColor = false;
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.Lime;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(585, 144);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(27, 20);
            this.button30.TabIndex = 28;
            this.button30.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button30.UseVisualStyleBackColor = false;
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.Color.Lime;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(559, 144);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(27, 20);
            this.button31.TabIndex = 27;
            this.button31.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button31.UseVisualStyleBackColor = false;
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.Lime;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(533, 144);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(27, 20);
            this.button32.TabIndex = 26;
            this.button32.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button32.UseVisualStyleBackColor = false;
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.Color.Lime;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(501, 144);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(34, 20);
            this.button33.TabIndex = 25;
            this.button33.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button33.UseVisualStyleBackColor = false;
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.Color.Yellow;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(715, 126);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(34, 20);
            this.button16.TabIndex = 42;
            this.button16.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Yellow;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(689, 126);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(27, 20);
            this.button17.TabIndex = 41;
            this.button17.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button17.UseVisualStyleBackColor = false;
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.Color.Lime;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(663, 126);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(27, 20);
            this.button18.TabIndex = 40;
            this.button18.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button18.UseVisualStyleBackColor = false;
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.Color.Lime;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(637, 126);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(27, 20);
            this.button19.TabIndex = 39;
            this.button19.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button19.UseVisualStyleBackColor = false;
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.Lime;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(611, 126);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(27, 20);
            this.button20.TabIndex = 38;
            this.button20.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button20.UseVisualStyleBackColor = false;
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.Color.Lime;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(585, 126);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(27, 20);
            this.button21.TabIndex = 37;
            this.button21.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button21.UseVisualStyleBackColor = false;
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.Yellow;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(559, 126);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(27, 20);
            this.button25.TabIndex = 36;
            this.button25.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button25.UseVisualStyleBackColor = false;
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.Color.Yellow;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(533, 126);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(27, 20);
            this.button26.TabIndex = 35;
            this.button26.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button26.UseVisualStyleBackColor = false;
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.Yellow;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(501, 126);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(34, 20);
            this.button27.TabIndex = 34;
            this.button27.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button27.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Yellow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(587, 57);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(30, 16);
            this.button1.TabIndex = 48;
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Lime;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(558, 57);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 16);
            this.button2.TabIndex = 47;
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Lime;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(529, 57);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(30, 16);
            this.button3.TabIndex = 46;
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Yellow;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(500, 57);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(30, 16);
            this.button4.TabIndex = 45;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Yellow;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(477, 57);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 16);
            this.button5.TabIndex = 44;
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Yellow;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(449, 57);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(30, 16);
            this.button6.TabIndex = 43;
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Yellow;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(717, 222);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(27, 20);
            this.button8.TabIndex = 65;
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Lime;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(691, 222);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(27, 20);
            this.button9.TabIndex = 64;
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.Color.Lime;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(665, 222);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(27, 20);
            this.button34.TabIndex = 63;
            this.button34.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button34.UseVisualStyleBackColor = false;
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.Lime;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(639, 222);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(27, 20);
            this.button35.TabIndex = 62;
            this.button35.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button35.UseVisualStyleBackColor = false;
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.Color.Lime;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(613, 222);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(27, 20);
            this.button36.TabIndex = 61;
            this.button36.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button36.UseVisualStyleBackColor = false;
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.Yellow;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(587, 222);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(27, 20);
            this.button37.TabIndex = 60;
            this.button37.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button37.UseVisualStyleBackColor = false;
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.Color.Yellow;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(561, 222);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(27, 20);
            this.button38.TabIndex = 59;
            this.button38.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button38.UseVisualStyleBackColor = false;
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.Color.Yellow;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(529, 222);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(34, 20);
            this.button39.TabIndex = 58;
            this.button39.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button39.UseVisualStyleBackColor = false;
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.Color.Yellow;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(717, 240);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(27, 20);
            this.button41.TabIndex = 56;
            this.button41.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button41.UseVisualStyleBackColor = false;
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.Lime;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(691, 240);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(27, 20);
            this.button42.TabIndex = 55;
            this.button42.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button42.UseVisualStyleBackColor = false;
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.Color.Lime;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(665, 240);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(27, 20);
            this.button43.TabIndex = 54;
            this.button43.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button43.UseVisualStyleBackColor = false;
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.Color.Lime;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(639, 240);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(27, 20);
            this.button44.TabIndex = 53;
            this.button44.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button44.UseVisualStyleBackColor = false;
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.Yellow;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(613, 240);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(27, 20);
            this.button45.TabIndex = 52;
            this.button45.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button45.UseVisualStyleBackColor = false;
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.Color.Yellow;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(587, 240);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(27, 20);
            this.button46.TabIndex = 51;
            this.button46.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button46.UseVisualStyleBackColor = false;
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.Lime;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(561, 240);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(27, 20);
            this.button47.TabIndex = 50;
            this.button47.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button47.UseVisualStyleBackColor = false;
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.Color.Lime;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(529, 240);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(34, 20);
            this.button48.TabIndex = 49;
            this.button48.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button48.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Lime;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(718, 417);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 16);
            this.button7.TabIndex = 71;
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.Yellow;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(690, 417);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 16);
            this.button40.TabIndex = 70;
            this.button40.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button40.UseVisualStyleBackColor = false;
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.Color.Lime;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(666, 417);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(30, 16);
            this.button49.TabIndex = 69;
            this.button49.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button49.UseVisualStyleBackColor = false;
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.Lime;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(637, 417);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 16);
            this.button50.TabIndex = 68;
            this.button50.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button50.UseVisualStyleBackColor = false;
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.Color.Yellow;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(608, 417);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(30, 16);
            this.button51.TabIndex = 67;
            this.button51.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button51.UseVisualStyleBackColor = false;
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.Color.Lime;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(579, 417);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(30, 16);
            this.button52.TabIndex = 66;
            this.button52.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button52.UseVisualStyleBackColor = false;
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.Color.Red;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(747, 417);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(30, 16);
            this.button53.TabIndex = 72;
            this.button53.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button53.UseVisualStyleBackColor = false;
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.Color.Lime;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(550, 417);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(30, 16);
            this.button54.TabIndex = 73;
            this.button54.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button54.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.Lime;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(527, 329);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 17);
            this.button55.TabIndex = 81;
            this.button55.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button55.UseVisualStyleBackColor = false;
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.Color.Lime;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(724, 329);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(30, 17);
            this.button56.TabIndex = 80;
            this.button56.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button56.UseVisualStyleBackColor = false;
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.Color.Lime;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(695, 329);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(30, 17);
            this.button57.TabIndex = 79;
            this.button57.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button57.UseVisualStyleBackColor = false;
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.Color.Yellow;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(667, 329);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(30, 17);
            this.button58.TabIndex = 78;
            this.button58.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button58.UseVisualStyleBackColor = false;
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.Color.Lime;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(643, 329);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(30, 17);
            this.button59.TabIndex = 77;
            this.button59.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button59.UseVisualStyleBackColor = false;
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.Color.Lime;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(614, 329);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(30, 17);
            this.button60.TabIndex = 76;
            this.button60.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button60.UseVisualStyleBackColor = false;
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.Color.Yellow;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(585, 329);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(30, 17);
            this.button61.TabIndex = 75;
            this.button61.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button61.UseVisualStyleBackColor = false;
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.Color.Lime;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(556, 329);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(30, 17);
            this.button62.TabIndex = 74;
            this.button62.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button62.UseVisualStyleBackColor = false;
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.Color.Lime;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(527, 345);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(30, 17);
            this.button63.TabIndex = 89;
            this.button63.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button63.UseVisualStyleBackColor = false;
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.Color.Lime;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(724, 345);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(30, 17);
            this.button64.TabIndex = 88;
            this.button64.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button64.UseVisualStyleBackColor = false;
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.Color.Lime;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Location = new System.Drawing.Point(695, 345);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(30, 17);
            this.button65.TabIndex = 87;
            this.button65.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button65.UseVisualStyleBackColor = false;
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.Color.Yellow;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Location = new System.Drawing.Point(667, 345);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(30, 17);
            this.button66.TabIndex = 86;
            this.button66.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button66.UseVisualStyleBackColor = false;
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.Color.Lime;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Location = new System.Drawing.Point(643, 345);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(30, 17);
            this.button67.TabIndex = 85;
            this.button67.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button67.UseVisualStyleBackColor = false;
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.Color.Red;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Location = new System.Drawing.Point(614, 345);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(30, 17);
            this.button68.TabIndex = 84;
            this.button68.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button68.UseVisualStyleBackColor = false;
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.Color.Yellow;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Location = new System.Drawing.Point(585, 345);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(30, 17);
            this.button69.TabIndex = 83;
            this.button69.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button69.UseVisualStyleBackColor = false;
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.Color.Lime;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Location = new System.Drawing.Point(556, 345);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(30, 17);
            this.button70.TabIndex = 82;
            this.button70.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button70.UseVisualStyleBackColor = false;
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.Color.Lime;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Location = new System.Drawing.Point(784, 97);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(18, 30);
            this.button71.TabIndex = 90;
            this.button71.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button71.UseVisualStyleBackColor = false;
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.Color.Lime;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Location = new System.Drawing.Point(784, 126);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(18, 30);
            this.button72.TabIndex = 91;
            this.button72.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button72.UseVisualStyleBackColor = false;
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.Color.Lime;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Location = new System.Drawing.Point(784, 155);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(18, 30);
            this.button73.TabIndex = 92;
            this.button73.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button73.UseVisualStyleBackColor = false;
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.Color.Lime;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Location = new System.Drawing.Point(784, 184);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(18, 30);
            this.button74.TabIndex = 93;
            this.button74.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button74.UseVisualStyleBackColor = false;
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.Color.Lime;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Location = new System.Drawing.Point(876, 85);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(17, 19);
            this.button77.TabIndex = 98;
            this.button77.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button77.UseVisualStyleBackColor = false;
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.Color.Lime;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Location = new System.Drawing.Point(892, 85);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(23, 19);
            this.button75.TabIndex = 99;
            this.button75.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button75.UseVisualStyleBackColor = false;
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.Color.Yellow;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Location = new System.Drawing.Point(930, 85);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(17, 19);
            this.button76.TabIndex = 101;
            this.button76.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button76.UseVisualStyleBackColor = false;
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.Color.Yellow;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Location = new System.Drawing.Point(914, 85);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(17, 19);
            this.button78.TabIndex = 100;
            this.button78.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button78.UseVisualStyleBackColor = false;
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.Color.Red;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Location = new System.Drawing.Point(930, 103);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(17, 19);
            this.button79.TabIndex = 105;
            this.button79.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button79.UseVisualStyleBackColor = false;
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.Color.Lime;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Location = new System.Drawing.Point(914, 103);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(17, 19);
            this.button80.TabIndex = 104;
            this.button80.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button80.UseVisualStyleBackColor = false;
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.Color.Yellow;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Location = new System.Drawing.Point(892, 103);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(23, 19);
            this.button81.TabIndex = 103;
            this.button81.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button81.UseVisualStyleBackColor = false;
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.Color.Yellow;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Location = new System.Drawing.Point(876, 103);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(17, 19);
            this.button82.TabIndex = 102;
            this.button82.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button82.UseVisualStyleBackColor = false;
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.Color.Lime;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Location = new System.Drawing.Point(853, 85);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(24, 19);
            this.button83.TabIndex = 106;
            this.button83.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button83.UseVisualStyleBackColor = false;
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.Color.Lime;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Location = new System.Drawing.Point(853, 103);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(24, 19);
            this.button84.TabIndex = 107;
            this.button84.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button84.UseVisualStyleBackColor = false;
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.Color.Yellow;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Location = new System.Drawing.Point(233, 300);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(18, 19);
            this.button85.TabIndex = 108;
            this.button85.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button85.UseVisualStyleBackColor = false;
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.Color.Lime;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Location = new System.Drawing.Point(253, 321);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(18, 19);
            this.button86.TabIndex = 109;
            this.button86.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button86.UseVisualStyleBackColor = false;
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.Color.Yellow;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Location = new System.Drawing.Point(233, 340);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(18, 19);
            this.button87.TabIndex = 110;
            this.button87.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button87.UseVisualStyleBackColor = false;
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.Color.Lime;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Location = new System.Drawing.Point(214, 320);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(18, 19);
            this.button88.TabIndex = 111;
            this.button88.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button88.UseVisualStyleBackColor = false;
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.Color.Lime;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Location = new System.Drawing.Point(784, 370);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(18, 30);
            this.button89.TabIndex = 115;
            this.button89.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button89.UseVisualStyleBackColor = false;
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.Color.Lime;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Location = new System.Drawing.Point(784, 341);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(18, 30);
            this.button90.TabIndex = 114;
            this.button90.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button90.UseVisualStyleBackColor = false;
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.Color.Lime;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Location = new System.Drawing.Point(784, 312);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(18, 30);
            this.button91.TabIndex = 113;
            this.button91.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button91.UseVisualStyleBackColor = false;
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.Color.Lime;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Location = new System.Drawing.Point(784, 283);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(18, 30);
            this.button92.TabIndex = 112;
            this.button92.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button92.UseVisualStyleBackColor = false;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.Color.Yellow;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Location = new System.Drawing.Point(385, 152);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(18, 15);
            this.button101.TabIndex = 127;
            this.button101.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button101.UseVisualStyleBackColor = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.Color.Lime;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Location = new System.Drawing.Point(402, 152);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(18, 15);
            this.button102.TabIndex = 126;
            this.button102.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button102.UseVisualStyleBackColor = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.Color.Lime;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Location = new System.Drawing.Point(402, 138);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(18, 15);
            this.button103.TabIndex = 128;
            this.button103.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button103.UseVisualStyleBackColor = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.Color.Lime;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Location = new System.Drawing.Point(385, 138);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(18, 15);
            this.button104.TabIndex = 129;
            this.button104.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button104.UseVisualStyleBackColor = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.Color.Yellow;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Location = new System.Drawing.Point(66, 137);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(18, 15);
            this.button105.TabIndex = 133;
            this.button105.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button105.UseVisualStyleBackColor = false;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.Color.Lime;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Location = new System.Drawing.Point(83, 137);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(18, 15);
            this.button106.TabIndex = 132;
            this.button106.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button106.UseVisualStyleBackColor = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.Color.Lime;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Location = new System.Drawing.Point(66, 151);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(18, 15);
            this.button107.TabIndex = 131;
            this.button107.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button107.UseVisualStyleBackColor = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.Color.Yellow;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Location = new System.Drawing.Point(83, 151);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(18, 15);
            this.button108.TabIndex = 130;
            this.button108.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button108.UseVisualStyleBackColor = false;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.Color.Yellow;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Location = new System.Drawing.Point(191, 207);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(12, 12);
            this.button109.TabIndex = 137;
            this.button109.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button109.UseVisualStyleBackColor = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.Color.Lime;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Location = new System.Drawing.Point(203, 207);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(12, 12);
            this.button110.TabIndex = 136;
            this.button110.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button110.UseVisualStyleBackColor = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.Color.Yellow;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Location = new System.Drawing.Point(191, 219);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(12, 12);
            this.button111.TabIndex = 135;
            this.button111.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button111.UseVisualStyleBackColor = false;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.Color.Red;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Location = new System.Drawing.Point(203, 219);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(12, 12);
            this.button112.TabIndex = 134;
            this.button112.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button112.UseVisualStyleBackColor = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.Color.Yellow;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Location = new System.Drawing.Point(269, 207);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(12, 12);
            this.button113.TabIndex = 141;
            this.button113.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button113.UseVisualStyleBackColor = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.Color.Lime;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Location = new System.Drawing.Point(281, 207);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(12, 12);
            this.button114.TabIndex = 140;
            this.button114.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button114.UseVisualStyleBackColor = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.Color.Lime;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Location = new System.Drawing.Point(269, 219);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(12, 12);
            this.button115.TabIndex = 139;
            this.button115.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button115.UseVisualStyleBackColor = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.Color.Yellow;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Location = new System.Drawing.Point(281, 219);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(12, 12);
            this.button116.TabIndex = 138;
            this.button116.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button116.UseVisualStyleBackColor = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.Color.Lime;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Location = new System.Drawing.Point(88, 207);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(12, 12);
            this.button117.TabIndex = 145;
            this.button117.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button117.UseVisualStyleBackColor = false;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.Color.Yellow;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Location = new System.Drawing.Point(100, 207);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(12, 12);
            this.button118.TabIndex = 144;
            this.button118.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button118.UseVisualStyleBackColor = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.Color.Lime;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Location = new System.Drawing.Point(88, 219);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(12, 12);
            this.button119.TabIndex = 143;
            this.button119.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button119.UseVisualStyleBackColor = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.Color.Yellow;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Location = new System.Drawing.Point(100, 219);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(12, 12);
            this.button120.TabIndex = 142;
            this.button120.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button120.UseVisualStyleBackColor = false;
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.Color.Lime;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Location = new System.Drawing.Point(372, 207);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(12, 12);
            this.button121.TabIndex = 149;
            this.button121.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button121.UseVisualStyleBackColor = false;
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.Color.Lime;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Location = new System.Drawing.Point(384, 207);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(12, 12);
            this.button122.TabIndex = 148;
            this.button122.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button122.UseVisualStyleBackColor = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.Color.Yellow;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Location = new System.Drawing.Point(372, 219);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(12, 12);
            this.button123.TabIndex = 147;
            this.button123.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button123.UseVisualStyleBackColor = false;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.Color.Yellow;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Location = new System.Drawing.Point(384, 219);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(12, 12);
            this.button124.TabIndex = 146;
            this.button124.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button124.UseVisualStyleBackColor = false;
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.Color.Lime;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Location = new System.Drawing.Point(377, 71);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(12, 12);
            this.button125.TabIndex = 153;
            this.button125.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button125.UseVisualStyleBackColor = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.Color.Lime;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Location = new System.Drawing.Point(389, 71);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(12, 12);
            this.button126.TabIndex = 152;
            this.button126.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button126.UseVisualStyleBackColor = false;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.Color.Yellow;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Location = new System.Drawing.Point(377, 83);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(12, 12);
            this.button127.TabIndex = 151;
            this.button127.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button127.UseVisualStyleBackColor = false;
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.Color.Yellow;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Location = new System.Drawing.Point(389, 83);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(12, 12);
            this.button128.TabIndex = 150;
            this.button128.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button128.UseVisualStyleBackColor = false;
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.Color.Lime;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Location = new System.Drawing.Point(323, 71);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(12, 12);
            this.button129.TabIndex = 157;
            this.button129.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button129.UseVisualStyleBackColor = false;
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.Color.Lime;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Location = new System.Drawing.Point(335, 71);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(12, 12);
            this.button130.TabIndex = 156;
            this.button130.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button130.UseVisualStyleBackColor = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.Color.Lime;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Location = new System.Drawing.Point(323, 83);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(12, 12);
            this.button131.TabIndex = 155;
            this.button131.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button131.UseVisualStyleBackColor = false;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.Color.Yellow;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Location = new System.Drawing.Point(335, 83);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(12, 12);
            this.button132.TabIndex = 154;
            this.button132.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button132.UseVisualStyleBackColor = false;
            // 
            // button133
            // 
            this.button133.BackColor = System.Drawing.Color.Yellow;
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Location = new System.Drawing.Point(270, 71);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(12, 12);
            this.button133.TabIndex = 161;
            this.button133.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button133.UseVisualStyleBackColor = false;
            // 
            // button134
            // 
            this.button134.BackColor = System.Drawing.Color.Lime;
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Location = new System.Drawing.Point(282, 71);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(12, 12);
            this.button134.TabIndex = 160;
            this.button134.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button134.UseVisualStyleBackColor = false;
            // 
            // button135
            // 
            this.button135.BackColor = System.Drawing.Color.Red;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Location = new System.Drawing.Point(270, 83);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(12, 12);
            this.button135.TabIndex = 159;
            this.button135.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button135.UseVisualStyleBackColor = false;
            // 
            // button136
            // 
            this.button136.BackColor = System.Drawing.Color.Lime;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Location = new System.Drawing.Point(282, 83);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(12, 12);
            this.button136.TabIndex = 158;
            this.button136.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button136.UseVisualStyleBackColor = false;
            // 
            // button137
            // 
            this.button137.BackColor = System.Drawing.Color.Lime;
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Location = new System.Drawing.Point(191, 71);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(12, 12);
            this.button137.TabIndex = 165;
            this.button137.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button137.UseVisualStyleBackColor = false;
            // 
            // button138
            // 
            this.button138.BackColor = System.Drawing.Color.Lime;
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Location = new System.Drawing.Point(203, 71);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(12, 12);
            this.button138.TabIndex = 164;
            this.button138.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button138.UseVisualStyleBackColor = false;
            // 
            // button139
            // 
            this.button139.BackColor = System.Drawing.Color.Yellow;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Location = new System.Drawing.Point(191, 83);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(12, 12);
            this.button139.TabIndex = 163;
            this.button139.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button139.UseVisualStyleBackColor = false;
            // 
            // button140
            // 
            this.button140.BackColor = System.Drawing.Color.Yellow;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Location = new System.Drawing.Point(203, 83);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(12, 12);
            this.button140.TabIndex = 162;
            this.button140.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button140.UseVisualStyleBackColor = false;
            // 
            // button141
            // 
            this.button141.BackColor = System.Drawing.Color.Lime;
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Location = new System.Drawing.Point(137, 71);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(12, 12);
            this.button141.TabIndex = 169;
            this.button141.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button141.UseVisualStyleBackColor = false;
            // 
            // button142
            // 
            this.button142.BackColor = System.Drawing.Color.Yellow;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Location = new System.Drawing.Point(149, 71);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(12, 12);
            this.button142.TabIndex = 168;
            this.button142.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button142.UseVisualStyleBackColor = false;
            // 
            // button143
            // 
            this.button143.BackColor = System.Drawing.Color.Yellow;
            this.button143.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button143.Location = new System.Drawing.Point(137, 83);
            this.button143.Name = "button143";
            this.button143.Size = new System.Drawing.Size(12, 12);
            this.button143.TabIndex = 167;
            this.button143.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button143.UseVisualStyleBackColor = false;
            // 
            // button144
            // 
            this.button144.BackColor = System.Drawing.Color.Yellow;
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Location = new System.Drawing.Point(149, 83);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(12, 12);
            this.button144.TabIndex = 166;
            this.button144.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button144.UseVisualStyleBackColor = false;
            // 
            // button145
            // 
            this.button145.BackColor = System.Drawing.Color.Lime;
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Location = new System.Drawing.Point(84, 71);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(12, 12);
            this.button145.TabIndex = 173;
            this.button145.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button145.UseVisualStyleBackColor = false;
            // 
            // button146
            // 
            this.button146.BackColor = System.Drawing.Color.Yellow;
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Location = new System.Drawing.Point(96, 71);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(12, 12);
            this.button146.TabIndex = 172;
            this.button146.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button146.UseVisualStyleBackColor = false;
            // 
            // button147
            // 
            this.button147.BackColor = System.Drawing.Color.Yellow;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Location = new System.Drawing.Point(84, 83);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(12, 12);
            this.button147.TabIndex = 171;
            this.button147.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button147.UseVisualStyleBackColor = false;
            // 
            // button148
            // 
            this.button148.BackColor = System.Drawing.Color.Yellow;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Location = new System.Drawing.Point(96, 83);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(12, 12);
            this.button148.TabIndex = 170;
            this.button148.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button148.UseVisualStyleBackColor = false;
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.Color.Lime;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Location = new System.Drawing.Point(66, 275);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(10, 10);
            this.button93.TabIndex = 177;
            this.button93.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button93.UseVisualStyleBackColor = false;
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.Color.Lime;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Location = new System.Drawing.Point(82, 275);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(10, 10);
            this.button94.TabIndex = 176;
            this.button94.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button94.UseVisualStyleBackColor = false;
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.Color.Lime;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Location = new System.Drawing.Point(66, 284);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(10, 10);
            this.button95.TabIndex = 175;
            this.button95.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button95.UseVisualStyleBackColor = false;
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.Color.Yellow;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Location = new System.Drawing.Point(82, 284);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(10, 10);
            this.button96.TabIndex = 174;
            this.button96.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button96.UseVisualStyleBackColor = false;
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.Color.Yellow;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Location = new System.Drawing.Point(66, 348);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(10, 10);
            this.button97.TabIndex = 181;
            this.button97.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button97.UseVisualStyleBackColor = false;
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.Color.Lime;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Location = new System.Drawing.Point(82, 348);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(10, 10);
            this.button98.TabIndex = 180;
            this.button98.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button98.UseVisualStyleBackColor = false;
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.Color.Red;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Location = new System.Drawing.Point(66, 357);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(10, 10);
            this.button99.TabIndex = 179;
            this.button99.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button99.UseVisualStyleBackColor = false;
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.Color.Yellow;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Location = new System.Drawing.Point(82, 357);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(10, 10);
            this.button100.TabIndex = 178;
            this.button100.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button100.UseVisualStyleBackColor = false;
            // 
            // button149
            // 
            this.button149.BackColor = System.Drawing.Color.Lime;
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Location = new System.Drawing.Point(433, 178);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(18, 30);
            this.button149.TabIndex = 185;
            this.button149.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button149.UseVisualStyleBackColor = false;
            // 
            // button150
            // 
            this.button150.BackColor = System.Drawing.Color.Lime;
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Location = new System.Drawing.Point(433, 149);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(18, 30);
            this.button150.TabIndex = 184;
            this.button150.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button150.UseVisualStyleBackColor = false;
            // 
            // button151
            // 
            this.button151.BackColor = System.Drawing.Color.Lime;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Location = new System.Drawing.Point(433, 120);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(18, 30);
            this.button151.TabIndex = 183;
            this.button151.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button151.UseVisualStyleBackColor = false;
            // 
            // button152
            // 
            this.button152.BackColor = System.Drawing.Color.Yellow;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Location = new System.Drawing.Point(433, 91);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(18, 30);
            this.button152.TabIndex = 182;
            this.button152.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button152.UseVisualStyleBackColor = false;
            // 
            // button153
            // 
            this.button153.BackColor = System.Drawing.Color.Lime;
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Location = new System.Drawing.Point(433, 207);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(18, 30);
            this.button153.TabIndex = 186;
            this.button153.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button153.UseVisualStyleBackColor = false;
            // 
            // MachinesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1047, 604);
            this.Controls.Add(this.button153);
            this.Controls.Add(this.button149);
            this.Controls.Add(this.button150);
            this.Controls.Add(this.button151);
            this.Controls.Add(this.button152);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button145);
            this.Controls.Add(this.button146);
            this.Controls.Add(this.button147);
            this.Controls.Add(this.button148);
            this.Controls.Add(this.button141);
            this.Controls.Add(this.button142);
            this.Controls.Add(this.button143);
            this.Controls.Add(this.button144);
            this.Controls.Add(this.button137);
            this.Controls.Add(this.button138);
            this.Controls.Add(this.button139);
            this.Controls.Add(this.button140);
            this.Controls.Add(this.button133);
            this.Controls.Add(this.button134);
            this.Controls.Add(this.button135);
            this.Controls.Add(this.button136);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MachinesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button button143;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
    }
}